thisfilename = 'RunCockpitv0.60.py'
#4/9/2021 client to Wing only - remove Tail connection, receive Tail data via Wing
#4/5/2021 Adding downdraft detection with annunciations
#4/2/2021 changed main loop display logic and speak logic to give priority to Flutter, Tipping, Stall
#3/28/2021 added audio power to d1[5], added d1[10:14] flutter f3-f7 to OLED tail 5 values
#3/22/2021 Updated to process dwx from tail and calculate ddpy and dayw from the wing and display above tipping_threshold on OLED
#3/12/2021 Update main_loop o1 to o1f[i] = math.sqrt(o1[i+1] * o1[i+7+1])/100 #skip o1[0] and o1[7] which are always large
#3/7/2021 Update main_loop o1 tail OLED display to show flutter spectra (o1[0:6] + o1[7:13])/300
#3/6/2021 Update main_loop o1 tail OLED display to show flutter spectra (o1[1:7] + o1[7:14])/150
#12/2/2020 modified to nolonger record wing, tail, cockpit separately, datafilepathW,datafilepathT, datafilepathC
#10/26/2020 replace 6 parameter cockpit cockpit2020_04_11_modelv6.h5 with 14 parameter 2020_10_23_oof_max.npy and 2020_10_23_modelv6.h5
#10/12/2020 replace ADXL345 with ISM330DHCX, recording wx,wy, wz, and all 8 audio bins
#7/20/2020 installed, checked out new OLED display
#6/22/2020 commented out OLED update to loss of wing or tail,
#added LED on, not blinking for loss of wing or tail, while waiting for replacement OLED display
#5/10/2020 added classify() using 18 prime_inputs.  Added speak_thread_function for bluetooth
#speaker annunciation of S,V,L,R using classify model
#Added pb3 GPIO 7 mark LOC switch detection, recorded as cockpit T oof = 2.0 during activation 4/24/2020
#Added exponential Temperature convergence to temperature_thread() 4/17/2020
#RunCockpitv0.3.py reads cockpit model, processes oof.  Displays cockpit, wing, tail oof
#RunCockpitv0.2.py had read_devices fft of mic to Amp, Freq (as was the case during 3 boxes build. build had accelerometer inside)
#RunCockpitv0.1.py had read_devices fft of mic to produce pf1, pf2 audio bins 0-500hz, 500hz- 1000hz
#3/12/2020 Ay is down, +G,  Az is Y, Ax is X.
bFlight = True

global bt_addr2 #wing

if bFlight:
    bt_addr2 = 'B8:27:EB:E4:D7:89' # this is the SPG Wing
    #bt_addr2= 'B8:27:EB:9B:11:80'#    this is the 2/3/2020 rpizero #sys.argv[1]
else:
    bt_addr2= 'B8:27:EB:9B:11:80'#    this is the 2/3/2020 rpizero #sys.argv[1]
    
global alpha_limt,tipping_limit,vrel_limit,flutter_limit,speak_stall_limit
tipping_limit = 1.8
vrel_limit = 560 #VNE
alpha_limit =666 #shows on OLED
speak_stall_limit = 630 #deep alpha
flutter_limit = 180 #
#downdraft limits reference flight 4/2/2021
wzt_limit = 0.10 #turning in thermal was 0.15
dwxt_limit = 0.5 #large tipping event had 0.7
downdraft_limit = 1.5 #2.0 was the largest excursion while thermalling.  = dwyt*dazt*ddpy/10
surge_limit = downdraft_limit/3
surge_dwxt_limit = 0.24*dwxt_limit #large tipping event had 0.7

def top():
    return
# version 0.1 for flight
# FOR FLIGHT - change voltage value, npoints max in main_loop, thisfilename in on.py, increment_log_number
import subprocess # for speaking
import time
import datetime
import math
import numpy as np
import bluetooth
import time
from struct import Struct
from struct import calcsize

import tensorflow as tf
from tensorflow import keras
# Adafruit_GPIO must be system wide installed from
# https://github.com/adafruit/Adafruit_Python_MCP3008
import Adafruit_GPIO as GPIO  # for switch and LED monitoring
# accelerometer adxl345 imports
from adafruit_platformdetect import Detector
detector = Detector()
print("Board id: ", detector.board.id)
import board
import busio

#add support for IMU
from adafruit_lsm6ds.ism330dhcx import ISM330DHCX
from adafruit_lsm6ds import Rate
from adafruit_lsm6ds import AccelRange
from adafruit_lsm6ds import GyroRange
i2c = busio.I2C(board.SCL, board.SDA)
imu = ISM330DHCX(i2c)
imu.gyro_range = GyroRange.RANGE_125_DPS
imu._set_gyro_range(125) #125 degrees/s and sets the 125 flag true
print('125 deg/s is ',imu._gyro_range_125dps)
print('imu.gyro_range = ',imu.gyro_range)

imu.gyro_data_rate = Rate.RATE_52_HZ
print('imu.gyro_data_rate (Rate.RATE_52_HZ = 3) ',Rate.string[imu.gyro_data_rate])

imu.accelerometer_range = AccelRange.RANGE_8G
print('imu.accelerometer_range  (AccelRange.RANGE_8G = 3) ',AccelRange.string[imu.accelerometer_range])
imu.accel_data_rate = Rate.RATE_52_HZ
print('imu.accel_data_rate (Rate.RATE_52_HZ = 3) ',Rate.string[imu.accel_data_rate])
# microphone imports
import audioop
import struct
import threading

########################## file paths ###################################
def increment_log_number():
    lognumber = np.load('./lognumber.npy')
    lognumber[0] = lognumber[0]+ 1
    np.save('./lognumber',lognumber)
    return lognumber[0]

def log(line):
     out=open(logfilepath,'a')
     date=datetime.datetime.now()
     out.write(str(date))
     out.write(': ')
     out.write(line)
     out.write('\n')
     out.close()
     return

lognumber = increment_log_number() #increment_log_number()
datafilepathA = time.strftime('./SPG-Flight/all%Y_%m_%d_') + str(lognumber)+str('.dat')
datafilepathW = time.strftime('./SPG-Flight/wing%Y_%m_%d_') + str(lognumber)+str('.dat')
datafilepathC = time.strftime('./SPG-Flight/cockpit%Y_%m_%d_') + str(lognumber)+str('.dat')
#10/12/2020 add local recording of cockpit
datafilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('.dat')

annunciatefilepath = time.strftime('./SPG-Flight/annunciate%Y_%m_%d_') + str(lognumber)+str('.dat')
logfilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('_log.txt')

#global variables
global process, values, bcontinuemicrophonethread
global oofmax, bcontinue, bluetooth_fail_count, bluetooth_failure_count_limit
# define our target boxes  wing , cockpit
global i2,d2,o2,bWing #wing data
global i3,d3,o3,bCockpit #cockpit data
nsamplerate = 8000 #be sure to change this in the subprocess arecord command string

#temperature imports
import glob
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'

pb1 = 24
pb2 = 23
pb3 = 7 # pin 26 pressure switch to mark intentional LOC for training

led = 26
speaker_id = '00:E0:4C:6A:B1:B9' # bluetooth device id of the cantor speaker
ledstate = False #to blink this in main loop

bluetooth_fail_count = 0 #if this is exceeded the main loop will call power cycle if pb1 is pressed
bluetooth_failure_count_limit = 4*3 #3mins should be long enough to boot up the wing and tail
def bluetooth_power_cycle():
    global bluetooth_fail_count
    bluetooth_fail_count = 0
    print('bluetooth_power_cycle')
    log('bluetooth_power_cycle')
    cmd = 'sudo rfkill block bluetooth'
    subprocess.call(cmd, shell=True)
    time.sleep(5)
    cmd = 'sudo rfkill unblock bluetooth'
    subprocess.call(cmd, shell=True)
    return

global phrase #used by speak_thread_function
def speak(annunciate):
    global phrase
    phrase = annunciate
    speak_thread = threading.Thread(target=speak_thread_function, args=())
    speak_thread.daemon = True  # so it will die on exit
    speak_thread.start()
    if not bFlight:
        print(phrase)
    return

global last_speak_time
last_speak_time = time.clock_gettime(0)
def speak_thread_function():
    global speaker_id,phrase, last_speak_time
    cmd = 'espeak "' # single quotes on the outside of a string, double quotes inside
    cmd = cmd + phrase + '" --stdout | aplay -D bluealsa:SRV=org.bluealsa,DEV='+ speaker_id 
    if (time.clock_gettime(0) - last_speak_time) > 5:
        last_speak_time = time.clock_gettime(0)
        log(cmd)
        print(cmd)
        subprocess.call(cmd, shell=True)
        time.sleep(2)
    return

def play_thread_function():
    global speaker_id,playfilepath
    cmd = 'aplay -D bluealsa:SRV=org.bluealsa,DEV=' + speaker_id + ' '+ playfilepath 
    log(cmd)
    print(cmd)
    subprocess.call(cmd, shell=True)
    return

global playfilepath
def play(file):
    global speaker_id, playfilepath
    playfilepath = file # can add a path to the files here
    play_thread = threading.Thread(target=play_thread_function, args=())
    play_thread.daemon = True  # so it will die on exit
    play_thread.start() 
    return

def prompt(index): #called by update3x6 (currently not enabled there)
    #play('out.wav')
    if index == 0:
        speak('Pit')
    if index == 1:
        speak('Wing')
    if index == 2:
        speak('Tail')
    return


def gpio_callback(pin):
    global bcontinue, bTail, bWing
    print('called back..' + str(pin))
    if gpio.is_low(pb1):
        print('GPIO 24 is low - display links')
        
    if gpio.is_low(pb2):
        print('GPIO 23 is low - quitting')
        log('GPIO 23 is low - quitting')
        #gpio.remove_event_detect(pb2)
        bcontinue = False

    return

# setup a GPIO monitoring of switch and pushbutton
gpio = GPIO.get_platform_gpio()  # determines if BeagleBone or Raspberry Pi
gpio.setup(pb1,GPIO.IN,GPIO.PUD_UP) # our switch interface
gpio.setup(pb2,GPIO.IN,GPIO.PUD_UP)
gpio.setup(pb3,GPIO.IN,GPIO.PUD_UP) # our mark LOC interface

gpio.setup(led,GPIO.OUT)
gpio.set_high(led)
# set an event that sleeps until pin 22 switch goes high
bouncetime = 500 #100 ms
#gpio.add_event_detect(pb1, GPIO.RISING, gpio_callback, bouncetime)
gpio.add_event_detect(pb2, GPIO.FALLING, gpio_callback, bouncetime)
#OLED
import digitalio
from PIL import Image, ImageDraw, ImageFont
import adafruit_ssd1306
# Change these
# to the right size for your display!
WIDTH = 128
HEIGHT = 32     # Change to 64 if needed
BORDER = 2
spi = busio.SPI(board.SCK, MOSI=board.MOSI)
reset_pin = digitalio.DigitalInOut(board.D14) # any pin! 14
dc_pin = digitalio.DigitalInOut(board.D15)    # any pin! 15
cs_pin = digitalio.DigitalInOut(board.D8)    # any pin!
oled = adafruit_ssd1306.SSD1306_SPI(128, 32, spi, dc_pin, reset_pin, cs_pin)

# Clear display.
def display_text(text=''):
    global old_display_text
    font = ImageFont.truetype("/usr/share/fonts/truetype/freefont/FreeMono.ttf", 17, encoding='')
    draw.text((0,0),old_display_text,font=font,fill=0) 
    draw.text((0,0),text,font=font,fill=255)
    old_display_text = text
    # Display image
    oled.image(image)
    oled.show()
    return

#initialize the out of family status array with a test pattern
display_test_array = [[0,1,0,1,0,1],[1,0,1,0,1,0],[0,1,0,1,0,1]]

def display3x6(array):
    global oof_array3x6, image,draw
    lw = 13
    hw = int((WIDTH-lw)/6)
    vh = int(HEIGHT/3)
    font = ImageFont.truetype("/usr/share/fonts/truetype/freefont/FreeMono.ttf", 12, encoding='')
    draw.text((0,0),'T',font=font,fill=255)
    draw.text((0,10),'W',font=font,fill=255)
    draw.text((0,20),'C',font=font,fill=255)
    for i in range(0,3):
        for j in range(0,6):
            #print('(%d,%d) %d' % (i,j, array[i][j]))
            shape = [(lw + j*hw,i*vh),(lw + j*hw + hw,i*vh + vh)]
            draw.rectangle(shape,array[i][j],0)
    
    oled.image(image)
    oled.show()
    return

def update3x6(row,oof): #oof is a > 1x6 array
    global oof_array3x6,btail,bwing         
    how_many = 0 #how many of the oof channels are triggered in a row
    for i in range(0,6):
        if oof[i] > 1.0:
            oof_array3x6[row][i] = 1
            how_many = how_many + 1
        else:
            oof_array3x6[row][i] = 0
    #if how_many > 6:
        #prompt(row)
    return

def clear_display():
    global image, draw
    image = Image.new('1', (oled.width, oled.height))
    # Get drawing object to draw on image.
    draw = ImageDraw.Draw(image)  #this will be screen buffer from now on
    oled.fill(0)
    oled.show()
    return

def temperature_thread_function():
    global bcontinueTemperaturethread, temperature
    #A measurement takes 800 ms, so spread these out every 100 s to reduce data time gaps
    #run an exponential model at the normal data rate dt, converging calculated temperature to
    #the most recent actual temperature measurement during the 100 s period.
    #Adjust the exponential constant K to give as smooth an extrapolation as possible
    Tenv_last = read_temperature()
    T_last = Tenv_last
    dt = 0.25 # data interval desired
    delta_t = 100 # measurement interval desired
    nsub = int(delta_t/dt)
    K= 0.5/delta_t # this produces e^-0.5 = 0.606 at the end of the 100s, 
    print('Started temperature reading..extrapolated points = %d' % nsub)
    log('Started temperature reading..extrapolated points = %d' % nsub)
    ncount = 1
    tstart = time.clock_gettime(0)
    
    while bcontinueTemperaturethread:   
        for n in range(0,nsub):
            temperature = Tenv_last + (T_last - Tenv_last) * np.exp(-K*n*dt)
            #print('T = %f' % temperature)
            time.sleep(dt)
        #we hav e modeled up to delta_t, time to get another measurement
        T_last = temperature        
        Tenv_last = read_temperature()
        ncount = ncount + 1
        
    tend = time.clock_gettime(0)
    print('temperature cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    print('Temperature thread terminated')
    log('temperature cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    log('Temperature thread terminated')
    return

def microphone_thread_function():
    global process, bcontinuemicrophonethread, values
    print('Started recording..')
    log('Started recording..')
    ncount = 0
    tstart = time.clock_gettime(0)
    while bcontinuemicrophonethread:
        values = read_microphone()
        dt = 0.001
        time.sleep(dt)
        #read all up to current time
        ntonow = int(dt * nsamplerate)
        audio = process.stdout.read(4 *ntonow )
        ncount = ncount + 1
    tend = time.clock_gettime(0)
    print('microphone cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    log('microphone cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    process.stdout.close()
    process.terminate()
    print('Microphone thread terminated')
    log('Microphone thread terminated')
    return
     
def read_accel():  
    accel = imu.acceleration
    #print("accel ", accel)
    return accel

def read_gyro():
    rates = imu.gyro
    #print("gyro ", rates)
    return rates

def read_microphone():
    global process, bcontinue, bcontinuemicrophonethread
    vals = [0 for i in range(0,nsamples)] # the 32 bit sound amplitudes
    if not bcontinuemicrophonethread:
        return vals
    
    for i in range(0,nsamples):
        audio = process.stdout.read(4 * 1)
        try:
            vals[i] = struct.unpack('<i', audio)[0]/2147483648
        except struct.error as e:
            print('No Cockpit Audio - check arecord is not running!')
            log('No Cockpit Audio - check arecord is not running!')
            bcontinuemicrophonethread = False #kill the thread
            bcontinue = False #stop the cockpit
            display_text('bad audio!')
            break
            
    return vals

def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines

def read_temperature():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.01)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c
    
def get_amp_freq(values):
    sp = np.fft.fft(values) #get the spectrum
    abs_sp = np.absolute(sp) # find the absolute vals of the complex values
    freq = np.fft.fftfreq(nsamples,1/nsamplerate) # make an array of frequencies corresponding to the  spectrum
    halffreq = int(nsamples/2) # the spectrum is symmetric about nsamples/2, 
    abs_sp1 = abs_sp[1:halffreq] #so just use freqencies up to halffreq
    amp = np.amax(abs_sp1)
    freq = np.where(abs_sp1 == amp)[0][0] # get the first occurrence,i.e. in the lowest index
    return amp, freq

def read_devices(): #gets the data, and writes it to a file
    global values, temperature, tzero,nsamples,datafile,datafilepath
    td = [0.0]*16 #makes list with 8 floating point zeros
    td[0] = time.clock_gettime(0) - tzero
    ax,ay,az =read_accel()
    wx,wy,wz = read_gyro()
    #(ax,ay,az)=(0,0,-10)
    #print('ax %f, ay %f, az %f' % (ax,ay, az))
    td[1] = ax
    td[2] = ay
    td[3] = az
    td[7] = wx
    td[8] = wy
    td[9] = wz
    #values are global and being updated by microphone_thread_function
    #bin the audio to distinguish 500 hz, in a range of 4000hz
    # 8 bins are 500 hz wide each
    audio_bins = bin_fft(values,8,8) # get just the first two bins, upto 1khz
    td[4] = audio_bins[0]
    td[5] = audio_bins[1]
    
    td[6] = temperature #updated by temperature thread every 10s
    
    #save the remaining audio bins to data file
    td[10] = audio_bins[2]
    td[11] = audio_bins[3]
    td[12] = audio_bins[4]
    td[13] = audio_bins[5]
    td[14] = audio_bins[6]
    td[15] = audio_bins[7]
    
    for listitem in td: # chnage this to td to record all the time and 8 channels
        datafile.write('%s ' % listitem)     
    
    datafile.write('\n')#all data is recorded
    datafile.close()
    datafile= open(datafilepath,'a')
    
    #amp,freq = get_amp_freq(values)
    #(amp,freq)=(0,0)
    #td[4] = amp #10.0 *amp
    #td[5] = freq #0.1*freq
    #skip temperature td[6]
    return [td[0],td[1],td[2],td[3],td[4],td[5],td[7],td[8],td[9],td[10],td[11],td[12],td[13],td[14],td[15]]


def update_block(dt,block,datazero,data_history_for_mav=[], moving_average = 1): # act first, then sleep dt
    vals = read_devices() # returns time, and the selected channels
    if moving_average > 1: #we need to compute moving average before adding to the block
        data_history_for_mav.pop(0)
        data_history_for_mav.append(vals)
        mav_vals = np.transpose(mav(np.transpose(data_history_for_mav),moving_average))[0]
        #print('mav_vals ' + str(mav_vals))
        block.pop(0)
        block.append(normalize(mav_vals[1:],datazero))
    else:
        block.pop(0)
        block.append(normalize(vals[1:],datazero))
        print(vals)
        
    time.sleep(dt)
    return vals

# make a function to normalize a single line from the import
# requires global datazero to have been calculatated
def normalize(ch,datazero):
    rv = rv = [(ch[0]-datazero[0])/10,(ch[1]-datazero[1])/10,(ch[2]-datazero[2])/10,
               (ch[3]-datazero[3])/1000,
               (ch[4]-datazero[4])/1000,
               (ch[5]-datazero[5])/100,(ch[6]-datazero[6])/100,(ch[7]-datazero[7])/100,
               (ch[8]-datazero[8])/100,(ch[9]-datazero[9])/100,(ch[10]-datazero[10])/100,(ch[11]-datazero[11])/100,
               (ch[12]-datazero[12])/100,(ch[13]-datazero[13])/100]
    return rv

def GetDataZero(data,number_of_takes=49): #cmf - we should only do this once, if we are running an online prediction
    # Get mean of first 50 samples and store value 
    dz = []
    #skip the zero index, which is time
    for idx in range(1, np.shape(data)[1]):
        dz.append(np.mean(data[0:number_of_takes, idx]))
    return dz

def onepair(nd,params): # nd is noddata from the preceding 'period' rows, with the 'period+1'th
    #expecting period + 1 rows
    td = np.array(nd).copy() # so we do not pollute nd refference
    td = np.transpose(td).tolist() #now period + 1 columns
    instances = []
    labels = []
    period = params['period']
    inst = []
    labl = []
    for ch in range(0,params['num_channels']):
        inst.append(td[ch][:period])         
        labl.append(td[ch][period])
    instances.append( [item for sublist in inst for item in sublist]) # flatten the list
    labels.append(labl)
    return instances, labels

def out_of_family(t, p, params, oofmax):
    nchannels = params['num_channels']
    oof = np.empty((0,nchannels), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nchannels], float)
        for ch in range(0,nchannels): # the channels
            val = math.sqrt((t[idx][ch] - p[idx][ch])*(t[idx][ch] - p[idx][ch]))
            channels[0,ch] = val / oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def signed_out_of_family_over_max(t, p,params,oofmax):
    nfeatures = params['num_channels']
    oof = np.empty((0,nfeatures), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nfeatures], float)
        for ch in range(0,nfeatures): # the channels
            val = (t[idx][ch] - p[idx][ch])
            channels[0,ch]=val/oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def plot_data(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    '''imports data as np.array'''
    data = np.loadtxt(datafilepathC)
    if finish_idx == 0:
        finish_idx = len(data)
    rawchannels = np.shape(data)[1]
    data = np.transpose(data[start_idx:finish_idx])
    times = data[0] # save for separate plot
    data = np.transpose(data[1:rawchannels]) #drop the time values in first row
    fig0 =plt.figure(0)
    fig0.suptitle(datafilepathC)
    ax=fig0.add_subplot(211)
    ax.set_title('Raw data beginning at ' + str(start_idx))
    ax.plot(data,label=['Ax', 'Ay', 'Az', 'pf1', 'pf2','T', 'Wx','Wy','Wz','pf3','pf4','pf5','pf6','pf7','pf8'])
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Ax', 'Ay', 'Az', 'pf1', 'pf2','T', 'Wx','Wy','Wz','pf3','pf4','pf5','pf6','pf7','pf8'])
    ax.grid(True)
    # plot times and intervals
    intervals = [0]
    for i in range(1,len(times)):
        intervals.append((times[i] - times[i-1])*1000)
    ax2=fig0.add_subplot(212)
    ax2.plot(list(range(start_idx,finish_idx)),times,list(range(start_idx,finish_idx)),intervals,label=['time','intervals'])
    ax2.legend(handles, ['time (s)','intervals (ms)'])
    ax2.grid(True)
    
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)
    return

def plot_mic_data( start_idx=0,finish_idx=0):
    global values # mic values from read_devices
    data = values 
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(data)
    tfactor = len(data)/nsamplerate
    times = [i/nsamplerate for i in range(0,len(data))] # save for separate plot
    fig0 =plt.figure(0)
    fig0.suptitle("Microphone Amplitude")
    ax=fig0.add_subplot(211)
    ax.set_title('Raw data beginning at ' + str(start_idx))
    t=[i for i in range(0,len(data))]
    d=data[start_idx:finish_idx]
    ax.plot(t,d)
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Amp'])
    ax.grid(True)
    sp = np.fft.fft(data)
    abs_sp = np.absolute(sp)
    freq = np.fft.fftfreq(len(times),1/nsamplerate)
    # plot freq and fft  
    ax2=fig0.add_subplot(212)
    halffreq = int(len(times)/2)

    plt.plot(freq[1:halffreq],abs_sp[1:halffreq],label=['freq','power'])    
    ax2.legend(handles, ['freq','power'])
    ax2.grid(True)
    
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)


def ask_shutdown() :
    display_text("Press pb2\nto exit 10s")
    time.sleep(2) # so we have time to un press
    for i in range(0,10):
        pb = gpio.input(pb2)
        #print("pb is "+str(pb))
        if pb == 0 :
            display_text('shutting\ndown')
            log('shutting down')
            subprocess.call('sudo shutdown now', shell=True)
        time.sleep(1) # can be subprocess call to shutdown

def display_link():#called when pb1 is pressed
    global bt_addr2
    cmd = ['hcitool','lq',bt_addr2]
    link = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout,stderr = link.communicate()
    if stdout == b'Not connected.\n':
        wing_link='wing 0'
    else: 
        wing_link = 'wing ' + "".join(chr(x) for x in stdout.split()[2])
    text = wing_link
    return text

def mav(data_by_row,N):
    x = data_by_row[0] #time is first row, which should not be averaged
    rmlength = len(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    rm = []
    rm.append(np.array(data_by_row[0][0:rmlength]))
    for j in range(1,np.shape(data_by_row)[0]):
        x = data_by_row[j]
        rm.append(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    return rm

def connect_local_cockpit():
    global bcontinueTemperaturethread, temperature, bcontinuemicrophonethread, nsamples, process
    global i3,d3,o3,bCockpit, values, datafilepath, datafile
    bCockpit = True
    ############################ initialize the TensorFlow TF2 model parameters
    params = {
        'hfactor': 1,
        'num_channels': 14,
        'period': 16,
        'num_hidden_layers': 1,
        }

    moving_average = 2 #update block processes the data with this
    modelfilepath = './SPG-Flight/2020_10_23_modelv6.h5'
    oofmaximumsfilepath = './SPG-Flight/2020_10_23_oof_max.npy'
    datazero=[-0.3826868042392857,9.719975024721428,0.42762547766071424,7.460541456813374,0.3403034151093696,0.0029319973103815455,
              -0.001851295670865414,-0.005325591713116625,0.15200378688952187,0.10928596340993996,0.08784007205448432,
              0.0751103045556391,0.06674864751991813,0.062324478004538095]
    # used in place of GetDataZero
    datazerosize = 49 #taken from train-cockpit-from-selected-range.ipynb used to produce the cockpit model
    ###################### timing #############################
    # get a block of data at a regular interval dt
    dtoh = 0.0437 # execution overhead is dependent on code 0.036 for v 0.40
    dt0 = 0.25 # data interval desired
    dt = dt0 - dtoh # is what we pass to sleep()
    #open the cockpit recording file for access by GetDataZero
    datafile = open(datafilepath,'w')
    ######################## period data for TF model #######################################
    blocksize = params['period'] + 1
    block = [[0.0]*(params['num_channels'])]*blocksize # will be blocksize rows x num channels columns of noddata
    ################initialize the history for moving average###############################
    data_history_for_mav=[[0.0]*(1+params['num_channels'])]*(moving_average + 1) # we will take the penultimate value of mav()
    #mic_process = start_mic_recording()
    # Launch our function in a thread
    nsamples = 1024 #8hz sample rate
    # e.g. arecord -D plughw:1 -d 5 -c 1 -r nsamplerate -f S32_LE -t wav -v mictest.wav
    values = [0 for i in range(0,nsamples)] # the 32 bit sound amplitudes
    cmd = ['arecord', '-D', 'plughw:1', '-f', 'S32_LE', '-c', '1', '-r', '8000','--disable-softvol', '-t', 'raw', '-q', '-']
    # r = rate, -V, --vumeter=TYPE      enable VU meter (TYPE: mono or stereo)
    # f = it seems only S32_LE is available
    # -c, --channels=#        channels, -t, --file-type TYPE    file type (voc, wav, raw or au)
    # q, --quiet             quiet mode
    #process = subprocess.Popen(['stdbuf', '-o0']+cmd, stdout=subprocess.PIPE)
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    time.sleep(1) # possibly this will give arecord to establish the audio stream before the microphone thread and read_microphone are called
    # get the first second as the microphone stabilizes
    for i in range(0,nsamplerate):
        process.stdout.read(4 * 1)
        
    print("Launching microphone thread")
    log("Launching microphone thread")
    bcontinuemicrophonethread = True
    mic_thread = threading.Thread(target=microphone_thread_function, args=())
    mic_thread.start()
    time.sleep(1)
    
    print("Launching temperature thread")
    log("Launching temperature thread")
    bcontinueTemperaturethread = True
    temperature = 0
    temperature_thread = threading.Thread(target=temperature_thread_function, args=())
    #temperature_thread.daemon = True  # so it will die on exit
    temperature_thread.start()
    time.sleep(1) #long enough so that the temperature and microphone threads produce data
    # Get datazerodata - better if it can be determined from previous data
    datazerodata = []
    for i in range(0,datazerosize):
        vals = read_devices() # this sleeps for time dt, uses datafile handle
        datazerodata.append(vals)
        time.sleep(dt)

############################ load the model #############################
    model = keras.models.load_model(modelfilepath)
########################### start the log ####################################
    log(modelfilepath)
    log(datafilepathC) # local cockpit IFI
    new_datazero = GetDataZero(np.array(datazerodata),datazerosize) # GetDataZero expects numpy array
    print('new datazero is ' + str(new_datazero))
    log('new datazero is ' + str(new_datazero))
#log('datazero assigned to be new data zero')
#datazero = new_datazero
    print('using datazero' + str(datazero))
    print('normalize new_datazero')
    log('normalize new_datazero')
    normalized_datazero = normalize(new_datazero,datazero)
    print(normalized_datazero)
    log(str(normalized_datazero))
    oofmax = np.load(oofmaximumsfilepath) # must be read in as initialization
    print('OOF maximums ' + str(oofmax))
    log('OOF maximums ' + str(oofmax))

    #initialize cockpit IFI lists
    #d3 = [0.0]*7
    #o3 = [0.0]*6
    #i3 = 0

    oofcount = 0
    maxoofcount = 3
    #oof_history = [] # not used here
    cockpit_count = 1 # a counter to estimate local cockpit data loop time
    tstart_cockpit = time.clock_gettime(0)
    
    while bCockpit:
        # get the cockpit update 
        d3 = update_block(dt, block,datazero,data_history_for_mav,moving_average) #sleeps dt, returns time, plus 6 values
        inst, t = onepair(block,params)
        p = model.predict_on_batch((inst,t)).numpy().tolist()
        o3 = signed_out_of_family_over_max(t, p,params,oofmax)[0]
        #oof is normalized to oof maximums.  If we want to scale for display, do it before update3x6
        #update3x6(0,oof) # cockpit is top row
        
        bprint = False
        if bprint:
            oofmaxval = np.amax(oof)
            if  oofmaxval > 1.0:
                if oofcount < maxoofcount :
                    result = np.where(oof == np.amax(oof))
                    index_max_oof = result[0].tolist()[0]
                    print('oof '+ str(oofmaxval) + ' at index '+ str(index_max_oof))
                    #speak(str(index_max_oof) + ' out of family')
                    oofcount = oofcount + 1
                    #log(str(oof))
                else : # we just had no out of family
                    oofcount = oofcount-  1
                    if oofcount < 0 :
                        oofcount = 0
        #update the index so the main loop will consider a new point
        i3 = i3 + 1
        cockpit_count = cockpit_count + 1  #yes, this is the same as i3, but is used to calculate cycle time
        #oof_history.append(oof)
        #print('connect_local_cockpit i3 = %d' % i3)
    tend = time.clock_gettime(0)
    interval = (tend - tstart_cockpit)/cockpit_count
    print("cockpit 6 channel read time (s) " + str(interval))
    log('cockpit 6 channel read time (s) ' + str(interval))
    bcontinuemicrophonethread = False
    print('Finishing microphone thread..')
    log('Finishing microphone thread..')
    bcontinueTemperaturethread = False
    print('Temperature thread finishing.. for 1 minute')
    log('Temperature thread finishing..for 1 minute')    
    print('Cockpit thread terminated')
    log('Cockpit thread terminated')
    return
    

def connect_socket_wing():
    global i2,d2,o2,bWing, bt_addr2
    global i1, d1,o1,bTail
    port2 = 0x1005 #must be odd, and same as WING port
    datagramformat = 'i42f' # integer record number, time for wing, 6 d2, 6 o2, time for tail,14 d1, 14 o1 
    MyStruct = Struct(datagramformat)
    datagramformatsize = calcsize(datagramformat)
    #create a time datagram to send the local time to tail
    timegramformat = '1d' #'1d1 is struct format for a double, unlike %
    timestruct = Struct(timegramformat)
    timegramformatsize = calcsize(timegramformat)

    sock2=bluetooth.BluetoothSocket(bluetooth.L2CAP)
    try:
        print("trying to connect to %s on PSM 0x%X" % (bt_addr2, port2))
        log("trying to connect to %s on PSM 0x%X" % (bt_addr2, port2))
        sock2.connect((bt_addr2, port2)) 
        localtime = time.clock_gettime(0)
        timegram = timestruct.pack(localtime)
        print('sending wing timegram %f' % localtime)
        log('sending wing timegram %f' % localtime)
        sock2.send(timegram)
        #sock2.send("go")
        print("connected to Wing server.  Receiving..")
        log("connected to Wing server.  Receiving..")
        bWing = True
        bTail = bWing
    except bluetooth.BluetoothError as e:
        print('unable to connect to Wing..')
        log('unable to connect to Wing..')
        bWing = False
        bTail = bWing
    #gather data
    #initialize Wing IFI lists
    #d2 = [0.0]*7
    #o2 = [0.0]*6
    #i2 = 0
    #gather datagrams
    data2 = b''
    datagram = b''
    #the first datagram sent should contain the start time, so log this
    try:
        data2 = sock2.recv(timegramformatsize) # blocking
        if len(list(data2)) == timegramformatsize:
            #i2_0 = 0
            #i1_0 = 0
            start_timeW = 0.0
            start_timeW = timestruct.unpack(data2)
            log('Wing start time:')
            logtimetext = '%f' % (start_timeW)
            log(logtimetext)
            print('Wing Start time %f' % start_timeW)
            
    except bluetooth.BluetoothError as e:
            sock2.close()
            print('wing server closed prematurely..')
            log('wing server closed prematurely..')
            bWing = False
            bTail = bWing
    
    while bWing:
        #time.sleep(0.1) #to let the calling thread execute
        try:
            data2 = sock2.recv(datagramformatsize) # blocking
            if len(list(data2)) == datagramformatsize:
                #print("sock1 datagram")
                datagram = MyStruct.unpack(data2)
                (i2,d2[0],d2[1],d2[2],d2[3],d2[4],d2[5],d2[6],o2[0],o2[1],o2[2],o2[3],o2[4],o2[5],
                 d1[0],d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],d1[7],d1[8],d1[9],d1[10],d1[11],d1[12],d1[13],d1[14],
                 o1[0],o1[1],o1[2],o1[3],o1[4],o1[5],o1[6],o1[7],o1[8],o1[9],o1[10],o1[11],o1[12],o1[13])= datagram
                
                i1 = i2
            else :
                bWing = False # bad data
                bTail = bWing
                sock2.close()
                print('bad Wing data..')
                log('bad Wing data..')
            #print("sock1 received: %s" % data1)
        except bluetooth.BluetoothError as e:
            sock2.close()
            print('wing server closed prematurely..')
            log('wing server closed prematurely..')
            bWing = False
            bTail = bWing
#    if bWing:
#        sock2.close()
    print('wing thread terminated')
    log('wing thread terminated')
    return

#used by cockpit
def bin_fft(data, nbins,stopat=0): # data will be audio values
    if stopat == 0: # stopat must be <=  nbins
        stopat = nbins
    
    sp = np.fft.fft(data)
    abs_sp = np.absolute(sp)
    halffreq = int(nsamples/2)
    abs_sp1 = abs_sp[1:halffreq]  # drop the first dc point
    binrange = int(len(abs_sp1)/nbins)
    #print(binrange)
    binleft = 0
    bins = [0]*nbins
    for j in range(0,stopat):
        binsum = 0
        #print(binleft,binleft+binrange)
        for i in range(binleft,binleft + binrange):# index stops at 1 less than binleft+binrange
            binsum = abs_sp1[i] + binsum
        bins[j] = binsum
        binleft = binleft + binrange
    return bins

##########globals for classifier#########################################
prime_inputs = [2,8,3,9,4,10,14,20,15,21,16,22,17,23,26,32,27,33] # see notebook assessment of the SPG data why these were chosen
datazeroC = [-0.3826868042392857,9.719975024721428,0.42762547766071424,7.460541456813374,0.3403034151093696,0.0029319973103815455,
              -0.001851295670865414,-0.005325591713116625,0.15200378688952187,0.10928596340993996,0.08784007205448432,
              0.0751103045556391,0.06674864751991813,0.062324478004538095]
cockpitlabeltext = ['Ax', 'Ay', 'Az', 'pf1', 'pf2', 'Wx','Wy','Wz','pf3','pf4','pf5','pf6','pf7','pf8'] 
datazeroW =[522.8163265306123,
 398.5204081632653,
 509.6530612244898,
 821.6173469387755,
 792.8316326530612,
 819.0102040816327]

winglabeltext = ['Ax', 'Ay', 'Az', 'dPz','dPy', 'dPx']
datazeroT = [0.45463629399999994,1.3674392760000003, -10.003567532, 2.1173941612361156, 0.08319944504656229, 21.125]
taillabeltext = ['Ax', 'Ay', 'Az', 'pf1', 'pf2', 'Wx','Wy','Wz','pf3','pf4','pf5','pf6','pf7','pf8']
classifymodelfilepath = './classify2020_05_01_v1p5_modelv6YES.h5'
time_history = 5
global prime_data_history, classify_model
prime_data_history = [[0.0]*len(prime_inputs)]*time_history
classify_model = keras.models.load_model(classifymodelfilepath)
classify_model.summary()
##############################################################################
# make a function to normalize a single line from the import
# requires global datazero to have been calculatated
def normalizeC(ch,datazero):
    rv = normalize(ch,datazero)
    return rv
# make a function to normalize a single line from the import
# requires global datazero to have been calculatated
def normalizeW(ch,datazero):
    channel_range = 1024 # a characteristice range of data values, min to max
    rv = []
    for idx in range(0,len(ch)):
        rv.append((ch[idx] - datazero[idx]) / channel_range)
    return rv

# requires global datazero to have been calculatated
#NOTE DIFFERENCE BETWEEN THIS AND COCKPIT, FOR SOUND
def normalizeT(ch,datazero):
    channel_range = 10 # a characteristice range of data values, min to max
    rv = [(ch[0]-datazero[0])/10,(ch[1]-datazero[1])/10,(ch[2]-datazero[2])/20,(ch[3]-datazero[3])/2000,
    (ch[4]-datazero[4])/600,(ch[5]-datazero[5])/100]
    return rv
    
def normalize_data(raw_data,datazero,normalize): # cmf note data is passed by reference!
    noddata = normalize(raw_data[1:],datazero) #skip the first column with time/index
    #print(noddata)
    return noddata #has no time

def normalize_prime_data(d1,o1,d2,o2,d3,o3):
    #construct a normalized + oof data array of the raw data, and include time
    global prime_data_history
    data_now = [0] #zero takes the place of the time field normally present in the first column
    #use the existing 3 box normalization functions for maintainability
    tp_T = normalize_data(d1,datazeroT,normalizeT)
    data_now = np.append(data_now, tp_T)
    data_now = np.append(data_now, o1)
    
    tp_W = normalize_data(d2,datazeroW,normalizeW)
    data_now = np.append(data_now, tp_W)
    data_now = np.append(data_now, o2)
    
    tp_C = normalize_data(d3,datazeroC,normalizeC)
    data_now = np.append(data_now, tp_C)
    data_now = np.append(data_now, o3) 
    #print(len(data_now))  #
    
    #prime inputs indices are zero based, since they pickout the raw data which had time
    prime_data_now =[]  #append the prime channels to be picked out
    
    for i in range(0,len(prime_inputs) ):
        prime_data_now.append(data_now[prime_inputs[i]])
    
    #update the prime_data_history
    prime_data_history.pop(0)
    prime_data_history.append(prime_data_now)
    
    return prime_data_history

global classify_annunciated_counter #if speaker annunciated, wait until this is exceeded before next
global classify_probability_threshold
classify_annunciated_counter = 0
classify_probability_threshold = 0.95 #greater than this, classify annunciates
#speak('Starting')

def classify(tsincestart, d1,o1,d2,o2,d3,o3):  #add to history, evaluate N,S,V,L,R and annunciate
    global classify_model, classify_annunciated_counter, annunciatefilepath
     #where the last 5 prime_data values are stored for classification
    prime_data_history = normalize_prime_data(d1,o1,d2,o2,d3,o3) 
    probabilities = classify_model.predict_on_batch(([prime_data_history],0)).numpy().tolist()[0]
    abnormal_classes = probabilities[1:]
    probability_data_text = '%f %f %f %f %f\n' % (tsincestart,abnormal_classes[0],abnormal_classes[1],abnormal_classes[2],abnormal_classes[3])
    annunciatefile = open(annunciatefilepath,'a')
    annunciatefile.write(probability_data_text)
    annunciatefile.close()
    annunciate = ''
    #print(probability_data_text)
    
    if abnormal_classes[0] > classify_probability_threshold:
        annunciate = 'Stall'
        playfile = 'push.wav'
    if abnormal_classes[1] > classify_probability_threshold:
        annunciate = 'Speed'
        playfile = 'pullup.wav'
    if abnormal_classes[2] > classify_probability_threshold: #classify_probability_threshold:
        annunciate = 'Left'
        playfile = 'pushright.wav'
    if abnormal_classes[3] > (classify_probability_threshold-0.15): #classify_probability_threshold:
        annunciate = 'Right'
        playfile = 'pushleft.wav'
     
    if (classify_annunciated_counter == 0) and (annunciate != ''):
        #speak(annunciate)
        #play(playfile)
        
        classify_annunciated_counter = 60  #60 = 15 seconds to decrement
    else:
        classify_annunciated_counter = classify_annunciated_counter - 1
        if classify_annunciated_counter < 0:
            classify_annunciated_counter = 0
    return

def start_placeholder(): # a dummy function to navigate to following executable statements f
    return
############################### executable statements ###########################
print(thisfilename)
log(thisfilename)
clear_display()
old_display_text = ''  # global used by display_text to remove the previous text
display_text(thisfilename[3:])

# define main loop actions, repeatable
def main_loop(bprint = False, maxnpoints=0):
    global bcontinue, oof_array3x6, tzero, bluetooth_fail_count, bluetooth_failure_count_limit
    global alpha_limit,vrel_limit, tipping_limit, flutter_limit,speak_stall_limit
    bcontinue = True
    main_loop_dt = 0.250 - 0.012 #
    print('starting main loop with dt = %f' % main_loop_dt)
    log('starting main loop with dt = %f' % main_loop_dt)
    tzero = time.clock_gettime(0)  # clock for this internal loop
    # also used by update_block, read_devices and connectdef main_loop(bprint = False, maxnpoints=0):_local_cockpit  
    #tail data used to be initalized in connect_socket_tail
    global i1,d1,o1, bTail,ledstate
     #initialize tail IFI -OBTAINED VIA WING
    d1 = [0.0]*15
    o1 = [0.0]*14 
    old_i1 = 0
    i1 = 0

    #wing data used to be initialized in connect_socket_wing
    global i2,d2,o2, bWing
    #initialize tail IFI lists
    d2 = [0.0]*7
    o2 = [0.0]*6
    old_i2 = 0
    i2 = 0
    wing_thread = threading.Thread(target=connect_socket_wing, args=())
    #wing_thread.daemon = True  # so it will die on exit
    wing_thread.start()
    time.sleep(5) # let bluetooth threads execute
    
    #cockpit data used to be initialized in connect_local_cockpit
    global i3,d3,o3,bCockpit
     #initialize Cockpit IFI lists
    d3 = [0.0]*15
    o3 = [0.0]*14
    #start the cockpit data recording , as the temperature, microphone thread starts and datazero update require 6 seconds
    old_i3 = 0
    i3 = 0
    mark_loc = False # toggles based on whether LOC switch activated
    cockpit_thread = threading.Thread(target=connect_local_cockpit, args=())
    #wing_thread.daemon = True  # so it will die on exit
    cockpit_thread.start()
    time.sleep(5)
    
    print(' bWing %d, bCockpit %d' % ( bWing, bCockpit))
    log(' bWing %d, bCockpit %d' % (bWing, bCockpit))
    #initialize OLED display variable

    cockpit_display_text = ''
    oof_array3x6 = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0,0]]
    all_row_oof = [2,2,2,2,2,2] #used to display loss of connection for that box
    clear_display()
    display_is_dirty = False
    display3x6(display_test_array)
    
    #initialize tipping differentials   
    dpy_last = d2[5]
    ayw_last = d2[2]
    wxt_last = d1[6]
    dwxtail = 0
    dayw = 0
    dwxt = 0
    ddpy = 0
    tipping = 0
    #initialize downdraft differentials
    wyt_last = d1[7]
    azt_last = d1[3]
    wzt = d1[8]
    dwyt = 0
    dazt = 0
    downdraft = 0
    
    loopcount = 1 #to stop a floating point error if abort before while bcontinue is True
    tstart = time.clock_gettime(0)
    print('Cockpit start time %f' % tstart)
    log('Cockpit start time:')
    log('%f' % tstart)
    print("START")
    tlastupdate = tstart #updated ever cycle time

    while bcontinue is True:
        #see if we have data from wing or tail or cockpit
        time.sleep(main_loop_dt/10) #check 10 x the rate of data
        tnow = time.clock_gettime(0)
        tsincestart = tnow - tstart
        
        #each of the 3 box's index changes store data ONLY IF IT HAS CHANGED - covers speaking as priority
                    
        if bWing: #fast response TIPPING is priority after FLUTTER
            assert(i1 ==i2)
            if i1 != old_i1:
                old_i1 = i1
                #tipping     #only update differentials for tail         
                dwxtail = d1[9]
                dwxt = d1[6] - wxt_last
                wxt_last = d1[6]
                #downdraft # only update differentials for tail
                dwyt = d1[7] - wyt_last
                dazt = d1[3] - azt_last
                wyt_last = d1[7]
                azt_last = d1[3]
                wzt = d1[8]
                
                old_i2 = i2
                #tipping #only update differentials for wing
                ddpy = d2[5] - dpy_last 
                dayw = d2[2] - ayw_last
                dpy_last = d2[5]
                ayw_last = d2[2]
                
                #process tail flutter PRIORITY
                
                if bWing: #calculate flutter
                    if int(d2[6]) < 830: #normal speed 
                        o1f = 6*[0]
                        for i in range(0,5):
                            o1f[i] = d1[10+i] #5 flutter values f3 through f7 using o1f[i] = math.sqrt(of[i+2] * of[i+7 + 2])/100

                        update3x6(0,o1f) # tail is top row
                        o1f = 6*[0] #clear this in case we loose updates from the tail
                    else:
                        update3x6(0,[0,0,0,0,0,0])
                    
                    #calculate CubeRoot(Wax4*Waz4*Vrel)
                    fl = np.cbrt((830 - int(d2[6]))*o1[3]*o1[10]) #o1 is zero based
                    if fl > flutter_limit:
                        if not bFlight:
                            print("TAIL %f" % fl)
                
                
                if bTail:
                    tipping = (dwxtail * ddpy *dayw)/1000.0
                    #tipping = (dwxt * ddpy *dayw)/1000.0                                  
                    
                    #display tipping on the bottom cockpit row of OLED
                    if tipping > tipping_limit:
                        update3x6(2,[2,2,2,0,0,0]) # cockpit is bottom row
                        print('LEFT!')
                    
                    elif tipping < (-tipping_limit):
                        update3x6(2,[0,0,0,2,2,2]) # cockpit is bottom row
                        print('RIGHT!')
                    else:
                        update3x6(2,[0,0,0,0,0,0])
                    
                    ##downdraft assessment
                    downdraft = dwyt*dazt*ddpy/10
                    if downdraft < (-downdraft_limit): #going down
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if np.abs(dwxtail) < dwxt_limit: #not rolling
                                print("LEAVE")
                        #turning left
                        if wzt < (-wzt_limit): #going left
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                print("CLOSE")
                            if dwxtail < (-dwxt_limit): #increasing left
                                print("LEAVE")
                            if dwxtail > dwxt_limit: #decreasing left
                                print("CLOSE")
                        #turning right
                        if wzt > wzt_limit: #going right
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                print("CLOSE")    
                            if dwxtail < (-dwxt_limit): #decreasing bank
                                print("CLOSE")
                                
                    if downdraft > surge_limit: #going up
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if dwxtail > surge_dwxt_limit: #rolling right
                                print("LEFT")
                            if dwxtail < (-surge_dwxt_limit): #rolling right
                                print("RIGHT")
                        
                #display alpha and vne on wing row of OLED
                        
                alpha = int(d2[5]) #d2[0] has wing time, so parameters shifted right
                vrel = int(d2[6]) #
                if vrel < 806 and alpha < alpha_limit:
                    update3x6(1,[2,0,0,0,0,0]) # wing is middle row
                    #if not bFlight:
                        #print('alpha')
                    if alpha < speak_stall_limit:
                        print("PUSH")
                        
                elif vrel < vrel_limit:
                    update3x6(1,[0,0,0,0,0,2]) # wing is middle row
                    print("PULL")

                else:
                    update3x6(1,[0,0,0,0,0,0]) # wing is middle row
                
                
                        
        if bCockpit:  #fast update 4 hz
            if i3 != old_i3:
                o3[3] = tipping #overwrites oof assignment in last update for Pf1
                o3[4] = downdraft #overwrites oof assignment for Pf2
                #print('c oof %s' % o3)
                #['Ax', 'Ay', 'Az', 'pf1', 'pf2', 'Wx','Wy','Wz','pf3','pf4','pf5','pf6','pf7','pf8'] 
                #see if the pressure switch is being marked for intentional LOC, and overwrite Temperature OOF
                if gpio.is_low(pb3):
                    if not mark_loc:
                        print('Mark LOC ON')
                        log('Mark LOC ON')
                        mark_loc = True
                
                    o3[0] = 2.0 #Triggers display Cockpit Ax
                else:
                    if mark_loc: # need to reset
                        print('Mark LOC OFF')
                        log('Mark LOC OFF')
                        mark_loc = False
                
                old_i3 = i3
                
                    
        #STORE ALL DATA into datafileA EVEN IF STATIC (main_loop_dt = 250 ms)
        if (time.clock_gettime(0) - tlastupdate) >= main_loop_dt:
            tlastupdate = tnow
            #update the loop count and display the states       
            loopcount = loopcount+1
            
            #store all our data in one file, with the local time since start
            taildata = str('%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f  '
                % (tsincestart,d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],d1[7],d1[8],d1[9],d1[10],d1[11],d1[12],d1[13],d1[14],
                o1[0],o1[1],o1[2],o1[3],o1[4],o1[5],o1[6],o1[7],o1[8],o1[9],o1[10],o1[11],o1[12],o1[13]))
            
            wingdata = '%f %f %f %f %f %f %f %f %f %f %f %f  '  % (d2[1],d2[2],d2[3],d2[4],d2[5],d2[6],o2[0],o2[1],o2[2],o2[3],o2[4],o2[5])
            if bWing and bTail and not bFlight:
                o3[3] = tipping
                o3[4] = downdraft
                #print('tip %f downdraft %f' % (o3[3], o3[4]))
                #print('downdraft dwyt*dazt*ddpy %f %f %f %f' % (o3[4], dwyt,dazt,ddpy))
                
            cockpitdata = str('%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n'  % 
                    (d3[1],d3[2],d3[3],d3[4],d3[5],d3[6],d3[7],d3[8],d3[9],d3[10],d3[11],d3[12],d3[13],d3[14],
                     o3[0],o3[1],o3[2],o3[3],o3[4],o3[5],o3[6],o3[7],o3[8],o3[9],o3[10],o3[11],o3[12],o3[13]))
                    
            alldata = taildata + wingdata + cockpitdata
            #print(alldata)
            datafileA = open(datafilepathA,'a')
            datafileA.write(alldata)
            datafileA.close()
            
            #classify(tsincestart,d1,o1,d2,o2,d3,o3) #add to history, evaluate N,S,V,L,R and annunciate
            
            #blink the LED, display loss of connection with tail, wing           
            if loopcount % 4 == 0:
                if bTail and bWing: #blink the LED
                    if ledstate == True:
                        ledstate = False
                        gpio.set_low(led)
                    else:
                        ledstate = True
                        gpio.set_high(led)
                        
                if bTail and not bWing: #show when we only have one connected
                    ledstate = True
                    gpio.set_high(led)
                if bWing and not bTail:
                    ledstate = True
                    gpio.set_high(led)
            #when OLED SSD1306 connected    
                if not bTail:
                    update3x6(0,all_row_oof)
                if not bWing:
                    update3x6(1,all_row_oof)
                
            #combo_text = ampfreqtext + d3d4text + cockpit_display_text
        
            if gpio.is_low(pb1): #left button is pushed, requesting bluetooth link strength
                text = display_link()
                print(text)
                clear_display()
                display_text(text)
                if bluetooth_fail_count > bluetooth_failure_count_limit:
                    bluetooth_power_cycle_thread = threading.Thread(target=bluetooth_power_cycle, args=())
                    bluetooth_power_cycle_thread.daemon = True  # so it will die on exit
                    bluetooth_power_cycle_thread.start()  #bluetooth_power_cycle resets bluetooth_fail_count
                    clear_display()
                    display_text('bluetooth\npower cycle')
                    time.sleep(5)  #this is how long the bluetooth power cycle takes
                display_is_dirty = True
            else:
                #display_text(combo_text)
                if display_is_dirty :
                    clear_display()
                    display_is_dirty = False
                    print('display cleared')
                
                display3x6(oof_array3x6)
            #print('tail %d wing %d %s' % (i1,i2,combo_text))
            #stop if we have exceeded the main_loop maxpoints value
            if (loopcount > maxnpoints) and (maxnpoints > 0) :
                bcontinue = False
            #try to reconnect if either bwing or btail is false after 60s
            if loopcount % 60 == 0:
                if bWing == False:
                    bluetooth_fail_count = bluetooth_fail_count + 1
                    d3d4text = ''
                    old_i2 = 0
                    i2 = 0
                    wing_thread = threading.Thread(target=connect_socket_wing, args=())
                    #wing_thread.daemon = True  # so it will die on exit
                    wing_thread.start()
                    time.sleep(.01) # let the threads start
                    print('bWing %d' % ( bWing))
                    log('bWing %d' % ( bWing))

        
    # finish up
    bCockpit = False #shuts down connect_local_cockpit
    tend = time.clock_gettime(0)
    interval = (tend - tstart)/loopcount 
    print("3 box loop time (s) " + str(interval))
    log('3 box loop time (s) ' + str(interval))
    return

bTail = False #these need to be initialized after global declarations
bWing = False
bCockpit = False
speak("") #seems to be needed to wake up bluetooth cantor
time.sleep(1)
main_loop(False,4*3600*5) #3 hours max = 4*3600*5

bTail = False
bWing = False
bCockpit = False

time.sleep(5) # let the threads finish
clear_display()
display_text('python3 exit..')
log('python3 exit..')
time.sleep(2)
display_text('')
gpio.set_low(led)
ask_shutdown()
#plot_oof(oof_history)
#plot_data()
#plot_mic_data(values)
#plot_data()
exit()



def bottom():
    return


    
    
    

    