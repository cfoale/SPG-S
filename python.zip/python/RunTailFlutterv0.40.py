thisfilename = 'RunTailFlutterv0.40.py'
#3/28/2021 added get_audio_power() and set in place of td[5] which was audio freq.  Audio freq is now td[6], replacing degC temperature.
#3/25/2021 added simulated data to read_accel read_gyro, read_devices
#3/22/2021 added read_flutter, flutter_thread_function to gather flutter data, and calculate dwx roll acceleration
#Replaced microphone pf1, pf2 with Amp and Freq.  Replaced pf3 with dwx, pf4-pf7 with flutter_values f3-f6 correlated flutter
#wax*waz frequency bins.  Using out of family o[0:14] to pass frequeny bins wax[0:7] and waz[0:7]
#3/9/2021 created variable flutter_sample_rate, to be logged.  unsuppressed flutterdatafile.dat recording (using .npy)
#3/7/2021 switched Az for Ay in sending of o[:]
#3/5/2021 commented out microphone raw data capture.  Added txt .dat flutterdatafilepath for cyclical saving
#of flutter data in lines of length 256x6.  Sending o[:] of binned flutter fft of Ax, Ay to Cockpit
#saving locally oofdatafile with time since start followed by o[0:14]
#1/7/2021 problem in main_loop ...(flutter_blocks % 5) was the save cycle!!!
#12/27/2020 bins now 256 in 4000 hz fft, 15.625 Hz wide.  Flutter_points 256.  microphone..npy recorded at
#same rate as flutter, in record_flutter_data
#10/14/2020 replace ADXL_345 and references in code with ISM330DHCX acclerometer and gyro
#this version 0.41 corresponds to a similar modification of RunCockpitv0.41.py
#incorporates changes to temperature_thread to apply converging exponential model to intermediate temperatures
def top():
    return
bFlight = True # we are simulating the tail, and suppressing all references to I2S, I2C, 1-wire
bSaveFlutterData = True #this is enables saving as a flutterdatafilepath.dat

if not bFlight:
    import random

# version 0.2 for flight RUN AS SUDO TO SET SERVER TIME
# FOR FLIGHT - change voltage value, npoints max in main_loop, thisfilename in on.py, increment_log_number
import subprocess # for speaking
import time
import datetime
import math
import numpy as np
import bluetooth
import time
from struct import Struct
from struct import calcsize

import tensorflow as tf
from tensorflow import keras
# Adafruit_GPIO must be system wide installed from
# https://github.com/adafruit/Adafruit_Python_MCP3008
import Adafruit_GPIO as GPIO  # for switch and LED monitoring
# accelerometer adxl345 imports
from adafruit_platformdetect import Detector
detector = Detector()
print("Board id: ", detector.board.id)
import board
import busio
if bFlight:
    from adafruit_lsm6ds.ism330dhcx import ISM330DHCX
    from adafruit_lsm6ds import Rate
    from adafruit_lsm6ds import AccelRange
    from adafruit_lsm6ds import GyroRange
    i2c = busio.I2C(board.SCL, board.SDA)
    imu = ISM330DHCX(i2c)
    imu.gyro_range = GyroRange.RANGE_125_DPS
    imu._set_gyro_range(125) #125 degrees/s and sets the 125 flag true
    print('125 deg/s is ',imu._gyro_range_125dps)
    print('imu.gyro_range = ',imu.gyro_range)

    #imu.gyro_data_rate = Rate.RATE_52_HZ
    imu.gyro_data_rate = Rate.RATE_208_HZ
    #print('imu.gyro_data_rate (Rate.RATE_52_HZ = 3) ',Rate.string[imu.gyro_data_rate])
    print('imu.gyro_data_rate (Rate.RATE_208_HZ = 5) ',Rate.string[imu.gyro_data_rate])
    
    imu.accelerometer_range = AccelRange.RANGE_8G
    print('imu.accelerometer_range  (AccelRange.RANGE_8G = 3) ',AccelRange.string[imu.accelerometer_range])
    #imu.accel_data_rate = Rate.RATE_52_HZ
    imu.accel_data_rate = Rate.RATE_208_HZ
    print('imu.accel_data_rate (Rate.RATE_208_HZ = 5) ',Rate.string[imu.accel_data_rate])

# microphone imports
import audioop
import struct
import threading
global mic_process, mic_values, bcontinuemicrophonethread, low_voltage, time_correction, nflutterpoints
time_correction = 0 # server_time - local time used to update clock after main_loop
nsamplerate = 8000 #be sure to change this in the subprocess arecord command string
nflutterpoints = 256 #used by read_flutter and record_flutter_data

#temperature imports
import glob
if bFlight:
    base_dir = '/sys/bus/w1/devices/'
    device_folder = glob.glob(base_dir + '28*')[0]
    device_file = device_folder + '/w1_slave'

moving_average = 1 #Average current point with  previous measurements - this effects import_data
datafilepath = ''
modelfilepath = './SPG-Flight/2020_10_23_modelv6.h5'
oofmaximumsfilepath = './SPG-Flight/2020_10_23_oof_max.npy'

#from train_tail_from_selected_ranges
datazero = [0.8575583199714286,
 0.23153000310714283,
 -9.624872534649999,
 1.1874150540034154,
 0.06655394385419448,
 0.007863331612110168,
 -0.008664313072400422,
 -0.00015271630954950385,
 0.040285527486419954,
 0.030732467434505223,
 0.024804941387167777,
 0.02156352232642454,
 0.01855270378142662,
 0.01646816052788548]

params = {
        'hfactor': 1,
        'num_channels': 14,
        'period': 16,
        'num_hidden_layers': 1,
        }

datazerosize = params['period']

low_voltage = 0 # this is monitored in the main_loop to determine if shutdown is required

def temperature_thread_function():
    global bcontinueTemperaturethread, temperature
    #A measurement takes 800 ms, so spread these out every 100 s to reduce data time gaps
    #run an exponential model at the normal data rate dt, converging calculated temperature to
    #the most recent actual temperature measurement during the 100 s period.
    #Adjust the exponential constant K to give as smooth an extrapolation as possible
    Tenv_last = read_temperature()
    T_last = Tenv_last
    dt = 0.25 # data interval desired
    delta_t = 100 # measurement interval desired
    nsub = int(delta_t/dt)
    K= 0.5/delta_t # this produces e^-0.5 = 0.606 at the end of the 100s, 
    print('Started temperature reading..extrapolated points = %d' % nsub)
    log('Started temperature reading..extrapolated points = %d' % nsub)
    ncount = 1
    tstart = time.clock_gettime(0)
    
    while bcontinueTemperaturethread:   
        for n in range(0,nsub):
            temperature = Tenv_last + (T_last - Tenv_last) * np.exp(-K*n*dt)
            #print('T = %f' % temperature)
            time.sleep(dt)
        #we hav e modeled up to delta_t, time to get another measurement
        T_last = temperature        
        Tenv_last = read_temperature()
        ncount = ncount + 1
        
    tend = time.clock_gettime(0)
    print('temperature cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    print('Temperature thread terminated')
    log('temperature cycle ncount %d, cycle time %f' % (ncount, (tend - tstart)/ncount))
    log('Temperature thread terminated')
    return

def microphone_thread_function():
    global mic_process, bcontinuemicrophonethread, mic_values
    print('Started recording..')
    log('Started recording..')
    ncount = 0
    tst = time.clock_gettime(0)
    while bcontinuemicrophonethread:
        mic_values = read_microphone()
        dts = 0.001
        time.sleep(dts) #skips more than 8 values
        #read all up to current time
        ntonow = int(dt * nsamplerate)
        audio = mic_process.stdout.read(4 *ntonow )
        ncount = ncount + 1
    tend = time.clock_gettime(0)
    print('micrphone cycle ncount %d, cycle time %f' % (ncount, (tend - tst)/ncount))
    log('micrphone cycle ncount %d, cycle time %f' % (ncount, (tend - tst)/ncount))
    mic_process.stdout.close()
    mic_process.terminate()
    print('Microphone thread terminated')
    log('Microphone thread terminated')
    return

global flutter_values, bcontinueflutterthread
flutter_values = 5*[0]
def flutter_thread_function():
    global bcontinueflutterthread, nflutterpoints, flutter_values #these will be 5 numbers accessed by read_devices
    print('Started flutter thread..')
    log('Started flutter thread..')
    ncount = 0
    tst = time.clock_gettime(0)
    while bcontinueflutterthread:
        flutter_values = read_flutter(nflutterpoints)
        dts = 0.001
        time.sleep(dts) #skips more than 8 values
        ncount = ncount + 1
    tend = time.clock_gettime(0)
    print('flutter cycle ncount %d, cycle time %f' % (ncount, (tend - tst)/ncount))
    log('flutter cycle ncount %d, cycle time %f' % (ncount, (tend - tst)/ncount))
    print('flutter thread terminated')
    log('flutter thread terminated')
    return

def increment_log_number():
    lognumber = np.load('./lognumber.npy')
    lognumber[0] = lognumber[0]+ 1
    np.save('./lognumber',lognumber)
    return lognumber[0]

def log(line):
     out=open(logfilepath,'a')
     date=datetime.datetime.now()
     out.write(str(date))
     out.write(': ')
     out.write(line)
     out.write('\n')
     out.close()
     return
    
#use a line of real data to help us simulate if required
#data at 1018.0614581108093 s, 2021_03_22_500.dat
    
one_measure = [ 2.3042881638, -0.0646062102, -11.789436950199999, #ax,ay,az
                89.89410108535652, 1.0, #amp, freq,
                -4.11060447057069,# temp
                -0.04283692482863583, -0.08139779298988555,0.009544769346843989, #wx,wy,wz
                0.06918048822592524, #dw
                0.22714624583052895, 0.17097850637850878,0.10641203281041582, #f3,f4,f5
                0.05784549360732656, 0.08193256397253135 ] #f6,f7
    
def read_accel():
    if not bFlight:
        t = time.clock_gettime(0) -tzero
        d = one_measure[0:3]
        d = d+ 0.1*(np.random.rand(3)-0.5*np.ones_like(d))
        if t > 50: # add vibration
            #print('read_accel t > 100')
            d[0] = d[0]+ 0.7*np.cos(2*3.142*8*t)+0.7*np.cos(2*3.142*16*t)
            d[1] = d[1]+ 0.8*np.cos(2*3.142*3*t)+2.0*np.sin(2*3.142*19*t)+0.8*np.cos(2*3.142*25*t)
            d[2] = d[2]+ 1.0*np.sin(2*3.142*1*t)+ 1.0*np.sin(2*3.142*10*t)+1.0*np.sin(2*3.142*20*t) + 0.4*np.sin(2*3.142*30*t)
        return d
    
    accel = imu.acceleration
    #print("accel ", accel)
    return accel

def read_gyro():
    if not bFlight:
        t = time.clock_gettime(0) -tzero
        d = one_measure[6:9]
        d= d+ 0.1*(np.random.rand(3)-0.5*np.ones_like(d))
        if t >50: #put rapid roll in
            #print('read_gyro t > 150')
            d[0] = d[0] + 0.5 *(np.sin(2*3.14*0.25*t)**5) #in out roll
            d[1] = d[1]+ .03*np.cos(2*3.14*2*t)+.02*np.cos(2*3.14*10*t) 
            d[2] = d[2]+ .03*np.cos(2*3.14*3*t)+ .01*np.cos(2*3.14*15*t)
        return d
    
    rates = imu.gyro
    #print("gyro ", rates)
    return rates

def read_microphone():
    global mic_process
    vals = [0 for i in range(0,nsamples)] # the 32 bit sound amplitudes
    for i in range(0,nsamples):
        audio = mic_process.stdout.read(4 * 1)
        vals[i] = struct.unpack('<i', audio)[0]/2147483648
    return vals

def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines

def read_temperature():
    if not bFlight:
        return one_measure[5] + np.random.rand()
    
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.01)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c

global flutter_data, flutter_sample_rate
flutter_data = [] #used for bulk data recording, if bSaveFlutterData
microphone_data = [] #used for bulk microphone data recording if enabled

def record_flutter_data(nflutterpoints,o):
    global flutter_data, microphone_data, oofdatafile,oofdatafilepath,flutter_sample_rate
    global flutterdatafile
    ts = time.clock_gettime(0)
    flutter = [] #used to gather a block of nflutterpoints = 256 x 6 for spectral analysis
   
    for i in range(0,nflutterpoints):
        a = imu.acceleration
        r = imu.gyro
        flutter.append([a[0],a[1],a[2],r[0],r[1],r[2]])
    #calculate the sample rate    
    dt = time.clock_gettime(0) - ts
    flutter_sample_rate = nflutterpoints/dt
    
    #flatten the flutter list   
    td = [item for sublist in flutter for item in sublist]    
    for listitem in td: # chnage this to td to record all the time and 8 channels
        flutterdatafile.write('%s ' % listitem)
        
    flutterdatafile.write('\n')
    flutterdatafile.close()
    flutterdatafile = open(flutterdatafilepath,'a')
    ##calculate a spectrum to be put into the oof array
    fd = np.array(flutter)
    axhist =  fd[:,0]
    o[0:7] = bin_fft(axhist,32,7)
    #ayhist =  fd[:,1]
    #o[7:14] = bin_fft(ayhist,32,7)
    azhist =  fd[:,2]
    o[7:14] = bin_fft(azhist,32,7)
    #create an array preceeded by the time
    od = 15*[0]
    od[0] = ts
    od[1:8] = o[0:7]
    od[8:15] = o[7:14]
   
    for listitem in od: # chnage this to td to record all the time and 8 channels
        oofdatafile.write('%s ' % listitem)
        
    oofdatafile.write('\n')
    oofdatafile.close()
    oofdatafile = open(oofdatafilepath,'a')
    #deltat = time.clock_gettime(0) - ts
    #print('flutter dt %f points %d' % (deltat, npoints))
    if bSaveFlutterData:
        flutter_data.append(flutter)
    ##microphone_data.append(values)
    return flutter

global of,flutter_last_measurements #last measurement value to calculate dwx
of = 14*[0] #array to hold bins of wax[0:7] and waz[0:7]
flutter_last_measurements = 6*[0] #holds a[], w[] last values from read_flutter

def read_flutter(nflutterpoints): # returns 6 binned values o[1:7] that can also be calculated in record_flutter_data
    global flutter_data, bSaveFlutterData,flutter_sample_rate, flutter_last_measurements #these are the latest
    global flutterdatafile, flutterdatafilepath, oofdatafile, offdatafilepath, of # 14*[0] array to hold bins of wax[0:7] and waz[0:7]
    ts = time.clock_gettime(0)
    flutter = []
    #dwx = flutter_last_measurements[6] # r[0]this will not change as we read in the flutter points, but could be accessed by read_devices
    #wxlast = flutter_last_measurements[3]
    for i in range(0,nflutterpoints):
        a = read_accel()
        r = read_gyro()   
        flutter.append([a[0],a[1],a[2],r[0],r[1],r[2]])
        flutter_last_measurements = [a[0],a[1],a[2],r[0],r[1],r[2]]
        
    time.sleep(0.001)
        
    #calculate the sample rate    
    dts = time.clock_gettime(0) - ts
    flutter_sample_rate = nflutterpoints/dts
    
    ##calculate a spectrum of Ax and Az to be put into the global of array
    of = 14*[0]
    fd = np.array(flutter)
    axhist =  fd[:,0]
    of[0:7] = bin_fft(axhist,32,7)

    azhist =  fd[:,2]
    of[7:14] = bin_fft(azhist,32,7)
    
    if bSaveFlutterData:
        flutter_data.append(flutter) #for immediate access after program end, uses lots of memory
        #flatten the flutter list   
        td = [item for sublist in flutter for item in sublist]    
        for listitem in td: # chnage this to td to record all the time and 8 channels
            flutterdatafile.write('%s ' % listitem)
        
        flutterdatafile.write('\n')
        flutterdatafile.close()
        flutterdatafile = open(flutterdatafilepath,'a')
        
    #we always safe an oof datafile with the spectral values    
    for listitem in of: # chnage this to td to record all the time and 8 channels
        assert(len(of) == 14)
        oofdatafile.write('%s ' % listitem)
        
    oofdatafile.write('\n')
    oofdatafile.close()
    oofdatafile = open(oofdatafilepath,'a')
    
    #create an array of 5 spectral values sqrt(wax*way), skipping the first two bins
    o1f = 5*[0]
    for i in range(0,5):
        o1f[i] = math.sqrt(of[i+2] * of[i+7 + 2])/100 #skip of[0], of[1] and of[7] and of[8] which are always large
    #print(o1f)   
    return o1f

global wxlast
wxlast =0;
def read_devices(): #gets the data, and writes it to a file, called by update_block
    global mic_values, flutter_values, temperature,datafile, nflutterpoints, tzero,flutter_last_measurements,wxlast
    td = [0.0]*16 #makes list with 8 floating point zeros
    td[0] = time.clock_gettime(0) - tzero
    #ax,ay,az =read_accel()
    #wx,wy,wz = read_gyro()
    #the flutter_thread_function calls read_flutter which calls read_accel, read_gyro, and saves flutter_last_measurements
    [ax,ay,az,wx,wy,wz] = flutter_last_measurements
    dwx = wx - wxlast
    wxlast = wx
    #print('ax %f, ay %f, az %f' % (ax,ay, az))
    td[1] = ax
    td[2] = ay
    td[3] = az
    td[7] = wx
    td[8] = wy
    td[9] = wz
    
    mean = np.mean(mic_values)
    sp = np.fft.fft(mic_values -mean) #mic_values has been updated by microphone_thread_function
    abs_sp = np.absolute(sp)
    #freq = np.fft.fftfreq(nsamples,1/nsamplerate)
    #print('len(freq) %d' %len(freq))
    halffreq = int(nsamples/2) #1024/2 = 512
    abs_sp1 = abs_sp[1:halffreq] #skipped [0], length = 511
    amp = np.amax(abs_sp1)
    freq = np.where(abs_sp1 == amp)[0][0] # get the first occurrence,i.e. lowest index
    #print('amp %f, freq %f' % (amp,freq))
    if not bFlight:
        td[4] = one_measure[3] + 10*np.random.rand()
        td[5] = one_measure[4] + 2*np.random.rand()
        print('read_devices time = %f' % td[0])
    else:
        td[4] = 10*amp
        td[5] = get_audio_power(mic_values)
    
    #bin the audio to distinguish 500 hz, in a range of 4000hz
    # 8 bins are 125 hz wide each
    #audio_bins = bin_fft(values,256,8) # get just the first 8 bins
    #td[4] = audio_bins[0]
    #td[5] = audio_bins[1]
    #if not bFlight:
        #td[4] =random.randint(0,10)
        #td[5] =random.randint(11,20)
    
    degC = temperature #updated by temperature thread every 10s
    td[6] = 0.1*freq
    #dwx is calculated above
    td[10] = dwx
    #calculate cross flutter
    td[11:16] = flutter_values #five of these
    
    for listitem in td: # chnage this to td to record all the time and 14 channels
        #  t      ax     ay    az    amp freq   T    wx     wy    wz   dwx    f3     f4     f5     f6     f7
        #[td[0],td[1],td[2],td[3],td[4],td[5],td[6],td[7],td[8],td[9],td[10],td[11],td[12],td[13],td[14],td[15]]
        datafile.write('%s ' % listitem)     
    
    datafile.write('\n')
    datafile.close()
    datafile = open(datafilepath,'a')
     #skip temperature td[6]
    #       t      ax     ay    az    amp freq   wx     wy    wz   dwx    f3     f4     f5     f6     f7
    return [td[0],td[1],td[2],td[3],td[4],td[5],td[7],td[8],td[9],td[10],td[11],td[12],td[13],td[14],td[15]] #dropped td[6], so 15 values

def update_block(dt,block,datazero,data_history_for_mav=[], moving_average = 1): # act first, then sleep dt
    vals = read_devices() # returns time, and the selected channels
    if moving_average > 1: #we need to compute moving average before adding to the block
        data_history_for_mav.pop(0)
        data_history_for_mav.append(vals)
        mav_vals = np.transpose(mav(np.transpose(data_history_for_mav),moving_average))[0]
        #print('mav_vals ' + str(mav_vals))
        block.pop(0)
        block.append(normalize(mav_vals[1:],datazero))
    else:
        block.pop(0)
        block.append(normalize(vals[1:],datazero))
        #print(vals)
        
    time.sleep(dt)

    return vals


def mav(data_by_row,N):
    x = data_by_row[0] #time is first row, which should not be averaged
    rmlength = len(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    rm = []
    rm.append(np.array(data_by_row[0][0:rmlength]))
    for j in range(1,np.shape(data_by_row)[0]):
        x = data_by_row[j]
        rm.append(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    return rm

# make a function to normalize a single line from the import
def normalize(ch,datazero):
    rv = rv = [(ch[0]-datazero[0])/10,(ch[1]-datazero[1])/10,(ch[2]-datazero[2])/10,
               (ch[3]-datazero[3])/1000,
               (ch[4]-datazero[4])/1000,
               (ch[5]-datazero[5])/100,(ch[6]-datazero[6])/100,(ch[7]-datazero[7])/100,
               (ch[8]-datazero[8])/100,(ch[9]-datazero[9])/100,(ch[10]-datazero[10])/100,(ch[11]-datazero[11])/100,
               (ch[12]-datazero[12])/100,(ch[13]-datazero[13])/100]
    return rv

def GetDataZero(data,number_of_takes=49): #cmf - we should only do this once, if we are running an online prediction
    # Get mean of first 50 samples and store value 
    dz = []
    for idx in range(1, np.shape(data)[1]):
        dz.append(np.mean(data[0:number_of_takes, idx]))
    return dz

def onepair(nd,params): # nd is noddata from the preceding 'period' rows, with the 'period+1'th
    #expecting period + 1 rows
    td = np.array(nd).copy() # so we do not pollute nd refference
    td = np.transpose(td).tolist() #now period + 1 columns
    instances = []
    labels = []
    period = params['period']
    inst = []
    labl = []
    for ch in range(0,params['num_channels']):
        inst.append(td[ch][:period])         
        labl.append(td[ch][period])
    instances.append( [item for sublist in inst for item in sublist]) # flatten the list
    labels.append(labl)
    return instances, labels

def out_of_family(t, p, params, oofmax):
    nchannels = params['num_channels']
    oof = np.empty((0,nchannels), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nchannels], float)
        for ch in range(0,nchannels): # the channels
            val = math.sqrt((t[idx][ch] - p[idx][ch])*(t[idx][ch] - p[idx][ch]))
            channels[0,ch] = val / oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def signed_out_of_family_over_max(t, p,params,oofmax):
    nfeatures = params['num_channels']
    oof = np.empty((0,nfeatures), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nfeatures], float)
        for ch in range(0,nfeatures): # the channels
            val = (t[idx][ch] - p[idx][ch])
            channels[0,ch]=val/oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def plot_oof(t):
    import matplotlib.pyplot as plt #slow load
    plt.plot(t)
    plt.grid(True)
    #plt.gca().set_ylim(0,0.5)
    plt.ion()
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)

def plot_data(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    '''imports data as np.array'''
    data = np.loadtxt(datafilepath)
    if finish_idx == 0:
        finish_idx = len(data)
    rawchannels = np.shape(data)[1]
    data = np.transpose(data[start_idx:finish_idx])
    times = data[0] # save for separate plot
    data = np.transpose(data[1:rawchannels]) #drop the time values in first row
    fig0,ax = plt.subplots(nrows=2,ncols=1,figsize=(10,10))
    fig0.suptitle(datafilepath)
    ax[0].set_title('Raw data beginning at ' + str(start_idx))
    ax[0].plot(data,label=["Ax", "Ay", "Az", "Amp", "Freq", "T", "wx", "wy", "wz", "dwx", "f3", "f4", "f5", "f6","f7"])
    handles, labels = ax[0].get_legend_handles_labels()
    ax[0].legend(handles, ["Ax", "Ay", "Az", "Amp", "Freq", "T", "wx", "wy", "wz", "dwx", "f3", "f4", "f5", "f6","f7"])
    ax[0].grid(True)
    # plot times and intervals
    intervals = [0]
    for i in range(1,len(times)):
        intervals.append((times[i] - times[i-1])*1000)
    ax[1].plot(list(range(start_idx,finish_idx)),times,list(range(start_idx,finish_idx)),intervals,label=['time','intervals'])
    ax[1].legend(handles, ['time (s)','intervals (ms)'])
    ax[1].grid(True)
    
    #plt.gca().set_ylim(0,1)
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)
    return

def plot_mic_data(data, start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(data)
    tfactor = len(data)/nsamplerate
    times = [i/nsamplerate for i in range(0,len(data))] # save for separate plot
    fig0 =plt.figure(0)
    fig0.suptitle("Microphone Amplitude")
    ax=fig0.add_subplot(211)
    ax.set_title('Raw data beginning at ' + str(start_idx))
    t=[i for i in range(0,len(data))]
    d=data[start_idx:finish_idx]
    ax.plot(t,d)
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Amp'])
    ax.grid(True)
    sp = np.fft.fft(data)
    abs_sp = np.absolute(sp)
    freq = np.fft.fftfreq(len(times),1/nsamplerate)
    # plot freq and fft  
    ax2=fig0.add_subplot(212)
    halffreq = int(len(times)/2)
    plt.plot(freq[1:halffreq],abs_sp[1:halffreq],label=['freq','power'])
    ax2.legend(handles, ['freq','power'])
    ax2.grid(True)
    
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)

def plot_flutter_data(flutter, start_idx=0,finish_idx=0,accel_max=100):
    global flutter_sample_rate
    tpfd = np.transpose(flutter)
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(tpfd[0])
    mems_sample_rate = flutter_sample_rate
    max_freq = int(0.5*flutter_sample_rate)
    t = [i/mems_sample_rate for i in range(0,len(tpfd[0]))] # save for separate plot
    fig0 =plt.figure(0)
    fig0.suptitle("flutter Amplitude")
    ax=fig0.add_subplot(211)
    ax.set_title('Raw data beginning at ' + str(start_idx))
    d0=tpfd[0][start_idx:finish_idx]
    d1=tpfd[1][start_idx:finish_idx]
    d2=tpfd[2][start_idx:finish_idx]
    ax.plot(t,d0,t,d1,t,d2,label=['Ax','Ay','Az'])
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Ax','Ay','Az'])
    ax.grid(True)
    ##ffts
    sp0 = np.fft.rfft(tpfd[0]-np.mean(tpfd[0]))
    abs_sp0 = np.absolute(sp0)
    sp1 = np.fft.rfft(tpfd[1]-np.mean(tpfd[1]))
    abs_sp1 = np.absolute(sp1)
    sp2 = np.fft.rfft(tpfd[2]-np.mean(tpfd[2]))
    abs_sp2 = np.absolute(sp2)
    f = np.arange(0,max_freq,max_freq/len(abs_sp0))
    # plot freq and fft  
    ax2=fig0.add_subplot(212)
    ax2.set_ylim(0,accel_max)
    ax2.plot(f,abs_sp0,f,abs_sp1,f,abs_sp2,label=['Ax','Ay','Az'])
    handles, labels = ax2.get_legend_handles_labels()
    ax2.legend(handles, ['Ax','Ay','Az'])
    ax2.grid(True)
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)
    return

def gpio_callback(pin):
    global bcontinue, low_voltage 
    #print('called back..' + str(pin))
    #log('called back..' + str(pin))
    if gpio.is_high(22):
        print('GPIO 22 is high - quitting')
        log('GPIO 22 is high - quitting')
        gpio.remove_event_detect(22) # so a subsequent push to shutdown fully does not trigger this
        bcontinue = False
        
    if gpio.is_high(8):
        #print('pin 8 is high - low voltage')
        #log('pin 8 is high - low voltage')
        low_voltage  = True #reset in main loop

    return

def ask_shutdown() :
    print("press push button to shutdown in 10 seconds")
    time.sleep(2) # so we have time to un press
    for i in range(0,10):
        pb = gpio.input(22)
        print("pb is "+str(pb))
        if pb != 0 :
            print('shutting down')
            log('shutting down')
            subprocess.call('sudo shutdown now', shell=True)
        time.sleep(1) # can be subprocess call to shutdown

# this adapter is hci0    B8:27:EB:81:A2:BF TAIL
def make_socket_listen():
    print("make_socket_listen..")
    log('make_socket_listen..')
    server_sock=bluetooth.BluetoothSocket( bluetooth.L2CAP )
    port = 0x1001
    server_sock.bind(("",port))
    server_sock.listen(1)
    return server_sock

def close_sockets(client_sock, server_sock):
    client_sock.close()
    server_sock.close()
    print('bluetooth sockets closed')
    log('bluetooth sockets closed..')
    return

def bluetooth_server_thread_function():
    global bcontinueserverthread, datagramindex,datagramsize,datagram, tstart, time_correction
    print('Launching bluetooth server thread')
    log('Launching bluetooth server thread')
    while bcontinueserverthread:
        try:
            server_sock = make_socket_listen()
            client_sock,address = server_sock.accept()
            print("Accepted connection from ",address)
            log('Accepted connection from '+ str(address))
            break
        except bluetooth.BluetoothError as e:
            print("unable to accept connection from "+str(address))
            close_sockets(client_sock, server_sock)
            time.sleep(1)

    #get setup to receive server time as double precision
    server_time_format = '1d' #'1d' is struct format for double, unlike %
    server_time_struct = Struct(server_time_format)
    timegramformatsize = calcsize(server_time_format)
    #receive the server time as 8 bytes, and set it
    data = client_sock.recv(timegramformatsize)
    try:
        server_time = server_time_struct.unpack(data)[0] #returned value is a tuple
        time_correction = server_time - time.clock_gettime(0)
        print('server - local time is %f' % time_correction)
        log('server - local time is %f' % time_correction)
        #time.clock_settime(0,server_time)
    except struct.error as e:
        print('Unable to receive server time..link failed')
        log('Unable to receive server time..link failed')
    #data = client_sock.recv(10)  #this used to be "go"
    #print("First Data received: ", str(data))
    #send the first datagram with the start time
    #timegram = datagram  #we do not want to pollute the original
    #timegram = MyStruct.pack(0, tstart,0,0,0,0,0,0,0,0,0,0,0,0)
    timegram = server_time_struct.pack(tstart)
    print('sending start time')
    log('sending start time')
    try:
        sent = client_sock.send(timegram)
        print('sent %d bytes, Start Time %f' % (sent, tstart))
        log('sent %d bytes, Start Time %f' % (sent, tstart))
    except bluetooth.BluetoothError as e:
        print("timegram failed")
        log('sending start time failed')
    
    ncount = 0
    olddatagramindex = 0 #not in the main range
    while bcontinueserverthread:
        if olddatagramindex != datagramindex:
            ncount = ncount + 1
            try:
            # b = bytes('foo.bar', 'utf8') # lets you specify a string to become bytes b
                #datagram = MyStruct.pack(datagramindex, False, 42.0,b'char data')
                sent = client_sock.send(datagram)
                olddatagramindex = datagramindex
                #sent = client_sock.send('Datagram  => ' + str(ncount))
                #print("sent %d bytes, index %d" % (sent, datagramindex))
            except bluetooth.BluetoothError as e:
                print("connection failed")
                time.sleep(1)
                close_sockets(client_sock, server_sock)
                time.sleep(1)
                server_sock = make_socket_listen()
                client_sock,address = server_sock.accept()
                print("Accepted connection from ",address)
                log('Accepted connection from '+ str(address))
                #receive the server time as 8 bytes, and set it
                data = client_sock.recv(timegramformatsize)
                try:
                    server_time = server_time_struct.unpack(data)[0] #returned value is a tuple
                    time_correction = server_time - time.clock_gettime(0)
                    print('server - local time is %f' % time_correction)
                    log('server - local time is %f' % time_correction)
                except struct.error as e:
                    print('Unable to receive server time..link failed')
                    log('Unable to receive server time..link failed')
                #data = client_sock.recv(10)
                #print("First Data received: ", str(data))
                #send the first datagram with the start time
                #timegram = datagram  #we do not want to pollute the original
                #timegram = MyStruct.pack(0, tstart,0,0,0,0,0,0,0,0,0,0,0,0)
                timegram = server_time_struct.pack(tstart)
                print('sending start time')
                try:
                    sent = client_sock.send(timegram)
                    print('sent %d bytes, Start Time %f' % (sent, tstart))
                    log('sent %d bytes, Start Time %f' % (sent, tstart))
                except bluetooth.BluetoothError as e:
                    print("timegram failed")
                    log('sending start time failed')
        time.sleep(.05) # faster than the main loop
    print("Terminating bluetooth server thread")
    log('Terminating bluetooth server thread')
    return

def get_audio_power(values): #integrate the squared powers
    mean = np.mean(values)
    amps = np.array(values) - mean
    powers = amps*amps
    return np.sum(powers)

def bin_fft(data, nbins,stopat=0): # data will be audio values
    if stopat == 0: # stopat must be <=  nbins
        stopat = nbins
    #new since 3/5/2021 - subtract the mean
    mean = np.mean(data)
    sp = np.fft.fft(data-mean)
    abs_sp = np.absolute(sp)
    halffreq = int(len(data)/2) #############3/8/2021 needs to become len(data)/2 - but upto today 1024/2
    abs_sp1 = abs_sp[1:halffreq]  # drop the first dc point
    binrange = int(len(abs_sp1)/nbins)
    #print(binrange)
    binleft = 0
    bins = [0]*nbins
    for j in range(0,stopat):
        binsum = 0
        #print(binleft,binleft+binrange)
        for i in range(binleft,binleft + binrange):# index stops at 1 less than binleft+binrange
            binsum = abs_sp1[i] + binsum
        bins[j] = binsum
        binleft = binleft + binrange
    return bins[0:stopat]

def start_placeholder(): # a dummy function to navigate to following executable statements f
    return
############################### globals and executable statements ###########################
global oofmax, bcontinue, datafile,flutterdatafilepath,flutterdatafile, oofdatfile, oofdatafilepath
########################## file paths ###################################
lognumber = increment_log_number() #increment_log_number()
datafilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('.dat')
logfilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('_log.txt')
microphonedatafilepath = time.strftime('./SPG-Flight/microphone%Y_%m_%d_') + str(lognumber)+str('.npy')
flutterdatafilepath = time.strftime('./SPG-Flight/flutter%Y_%m_%d_') + str(lognumber)+str('.dat')
oofdatafilepath = time.strftime('./SPG-Flight/oof%Y_%m_%d_') + str(lognumber)+str('.dat')
###################### timing #############################
# get a block of data at a regular interval dt
dtoh = 0.05 # execution overhead is dependent on code 0.158 in RunTailv0.31.py
dt0 = 0.25 # data interval desired
dt = dt0 - dtoh # is what we pass to sleep()
tzero = time.clock_gettime(0)  # this is a reference for times saved by read_devices
######################## period data for TF model #######################################
blocksize = params['period'] + 1
block = [[0.0]*(params['num_channels'])]*blocksize # will be blocksize rows x num channels columns of noddata
################initialize the history for moving average###############################
data_history_for_mav=[[0.0]*(1+params['num_channels'])]*(moving_average + 1) # we will take the penultimate value of mav()

datafile = open(datafilepath,'w')
flutterdatafile = open(flutterdatafilepath,'w')
oofdatafile = open(oofdatafilepath,'w')

# Launch our function in a thread
nsamples = 1024 #8hz sample rate
# e.g. arecord -D plughw:1 -d 5 -c 1 -r nsamplerate -f S32_LE -t wav -v mictest.wav
mic_values = [0 for i in range(0,nsamples)] # the 32 bit sound amplitudes
cmd = ['arecord', '-D', 'plughw:1', '-f', 'S32_LE', '-c', '1', '-r', '8000','--disable-softvol', '-t', 'raw', '-q', '-']
# r = rate, -V, --vumeter=TYPE      enable VU meter (TYPE: mono or stereo)
# f = it seems only S32_LE is available
# -c, --channels=#        channels, -t, --file-type TYPE    file type (voc, wav, raw or au)
# q, --quiet             quiet mode
#process = subprocess.Popen(['stdbuf', '-o0']+cmd, stdout=subprocess.PIPE)
mic_process = subprocess.Popen(cmd, stdout=subprocess.PIPE)
# get the first second as the microphone stabilizes
for i in range(0,nsamplerate):
    mic_process.stdout.read(4 * 1)
    
print("Launching microphone thread")
log("Launching microphone thread")
bcontinuemicrophonethread = True
mic_thread = threading.Thread(target=microphone_thread_function, args=())
mic_thread.start()

print("Launching flutter thread")
log("Launching flutter thread")
bcontinueflutterthread = True
flutter_thread = threading.Thread(target=flutter_thread_function, args=())
flutter_thread.start()

global bcontinueTemperaturethread, temperature
bcontinueTemperaturethread = True
temperature = 0
temperature_thread = threading.Thread(target=temperature_thread_function, args=())
temperature_thread.daemon = True  # so it will die on exit
temperature_thread.start()

############################ load the model #############################
model = keras.models.load_model(modelfilepath)
time.sleep(1)
#fetch datazerodata - better if it can be determined from previous data
print('Reading zerodata %d param[period] points' % datazerosize)
datazerodata = []
for i in range(0,datazerosize):
    vals = read_devices() # this sleeps for time dt, uses datafile handle
    datazerodata.append(vals)
    time.sleep(dt)


########################### start the log ####################################
print(thisfilename)
log(thisfilename)
log(modelfilepath)
log(datafilepath)
log(flutterdatafilepath)
new_datazero = GetDataZero(np.array(datazerodata),datazerosize) # GetDataZero expects numpy array
print('new datazero is ' + str(new_datazero))
log('new datazero is ' + str(new_datazero))
#log('datazero assigned to be new data zero')
#datazero = new_datazero
print('using datazero' + str(datazero))
print('normalize new_datazero')
log('normalize new_datazero')
normalized_datazero = normalize(new_datazero,datazero)
print(normalized_datazero)
log(str(normalized_datazero))
oofmax = np.load(oofmaximumsfilepath) # must be read in as initialization
print('OOF maximums ' + str(oofmax))
log('OOF maximums ' + str(oofmax))

# setup a GPIO monitoring of switch and pushbutton
gpio = GPIO.get_platform_gpio()  # determines if BeagleBone or Raspberry Pi
gpio.setup(22,GPIO.IN,GPIO.PUD_DOWN) # our switch interface
gpio.setup(8,GPIO.IN,GPIO.PUD_OFF)
# set an event that sleeps until pin 22 switch goes high
bouncetime = 500 #100 ms
#GPIO8 goes high at low voltage
gpio.add_event_detect(8, GPIO.RISING, gpio_callback, bouncetime)

#setup server
global bcontinueserverthread, datagramindex, datagram, MyStruct
bcontinueserverthread = True
datagramindex = 0 # this is initialized in server thread as well, so datagram considered sent already
datagramformat = 'i29f' # = 1 + 2 x 14 = 1 + 2 x num_channels
datagramsize = calcsize(datagramformat)
print('datagram size %d' % datagramsize)
log('datagram size %d' % datagramsize)
MyStruct = Struct(datagramformat) # used to pack the datagram
datagram = MyStruct.pack(datagramindex,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,
                         .0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0)

#initialize tstart before the bluetooth server, as it sends tstart
tstart = time.clock_gettime(0)
bluetooth_thread = threading.Thread(target=bluetooth_server_thread_function, args=())
bluetooth_thread.daemon = True  # so it will die on exit
bluetooth_thread.start()

# define main loop actions, keeps on making new datagrams for sending by
#bluetooth_server_thread_function, saving in local file
def main_loop(bprint = False, maxnpoints=0):
    global oof_history, datafile, flutterdatafilepath, nflutterpoints,flutterdatafile
    global bcontinue, oofdatafilepath, oofdatafile, of
    global low_voltage
    global datagramindex, datagram
    log('starting main loop .. ')
    global tstart
    global flutter_data, microphone_data
    
    log('starting main loop .. ')

    log('start time %f' % tstart)
    npoints = 0
    # setup event to detect pushbutton to exit the loop
    gpio.add_event_detect(22, GPIO.RISING, gpio_callback, bouncetime)
    
    bcontinue = True
    last_was_low_voltage = False #to keep track of successive low voltage detections
    low_voltage_count = 0
    oofcount = 0
    maxoofcount = 3
    datagramindex = 0
    #flutter_blocks = 1
    last_low_voltage_time = time.clock_gettime(0)
    log('first flutter measurement at dt = %f' % (time.clock_gettime(0)-tstart))
    while bcontinue is True:
        #for flutter_time gather data
        o = of # 14*[] temporary use of oof to save and pass the wax and waz frequency bins
        #if bFlight:
            #record_flutter_data(flutter_points,o)#appends fd to flutterdatafile
        #else:
            #o=np.random.randint(150, size=(14)).tolist() # random values 0-149 in array[14]
        #print('ax ' + str(o[0:7]))
        #print('ay ' + str(o[7:14]))
        # get enough data to do a new assessment of IFI
        #for i in range(0,params['period']):
        d = update_block(dt, block,datazero,data_history_for_mav,moving_average) #sleeps dt, returns time, plus 6 values
        #inst, t = onepair(block,params)
        #p = model.predict_on_batch((inst,t)).numpy().tolist()
        #o = out_of_family(t, p,params,oofmax)[0]
        
        datagramindex = datagramindex + 1
        # MyStruct has been formatted at start to be 'i13f'
        datagram = MyStruct.pack(datagramindex, d[0],d[1],d[2],d[3],d[4],d[5],d[6],d[7],d[8],d[9],d[10],d[11],d[12],d[13],d[14],
                o[0],o[1],o[2],o[3],o[4],o[5],o[6],o[7],o[8],o[9],o[10],o[11],o[12],o[13])
        
        #time.sleep(0.05) # pause to let bluetooth server thread send, 
        # greater than delay in bluetooth_server_thread_function (0.01)
        if bprint:
            oofmaxval = np.amax(oof)
            if  oofmaxval > 1.0:
                if oofcount < maxoofcount :
                    result = np.where(oof == np.amax(oof))
                    index_max_oof = result[0].tolist()[0]
                    #print('oof '+ str(oofmaxval) + ' at index '+ str(index_max_oof))
                    #speak(str(index_max_oof) + ' out of family')
                    #prompt(index_max_oof)
                    oofcount = oofcount + 1
                    #log(str(oof))
                else : # we just had no out of family
                    oofcount = oofcount-  1
                    if oofcount < 0 :
                        oofcount = 0
        #look for successive low_voltage annunciation each loop                
        if low_voltage : #set by gpio_callback
            time_now = time.clock_gettime(0)
            low_voltage_time = time_now - last_low_voltage_time
            print('time since last low_voltage %d' % low_voltage_time)
            log('time since last low_voltage %d' % low_voltage_time)
            if low_voltage_time  <  1:
                    #bcontinue = False
                    log('low voltage shutdown! %f' % low_voltage_time)
                    print('low voltage shutdown! %f' % low_voltage_time)
                    subprocess.call('sudo shutdown now', shell=True)
            last_low_voltage_time = time_now
            #print('last_was_low_voltage set True')
            low_voltage = False #has to be set again by gpio callback

        npoints = npoints + 1  # a stop point if the switch is not used
        if (npoints > maxnpoints) and (maxnpoints > 0) :
            bcontinue = False
    # finish up
    tend = time.clock_gettime(0)
    interval = (tend - tstart)/npoints
    print("6 channel read time (s) " + str(interval))
    log('6 channel read time (s) ' + str(interval))
    
    return

if not bFlight:
    main_loop(False,4*300) #5 hours max 4*3600*5)
else:
    main_loop(False, 4*3600*5) #5 hours max 4*3600*5)
bcontinueserverthread = False
print('Server finishing')
log('Server finishing')
bcontinuemicrophonethread = False
print('Finishing microphone..')
log('Finishing microphone..')
bcontinueflutterthread = False
print('Finishing flutter..')
log('Finishing flutter..')
bcontinueTemperaturethread = False
print('Temperature thread finishing')
log('Temperature thread finishing')
time.sleep(5) #let the threads terminate
datafile.close()
flutterdatafile.close()
oofdatafile.close()
    
print('flutter sample rate %f' % flutter_sample_rate)
log('flutter sample rate %f' % flutter_sample_rate)
if bSaveFlutterData:
    log('flutter_data length %d' % len(flutter_data))
    #log('saving  flutter at dt = %f' % (time.clock_gettime(0)-tstart))
    #np.save(flutterdatafilepath + '.npy', flutter_data)
    #np.save(microphonedatafilepath,microphone_data)
    #log('done saving at dt = %f' % (time.clock_gettime(0)-tstart))
else:
    print('flutter_data .npy not saved - not recorded')
    log('flutter_data not saved - not recorded')
    
gpio.remove_event_detect(22)
#plot_flutter_data(flutter_data[0])

if bFlight:
    #set the time to be that of the server
    local_time_correction = time_correction + time.clock_gettime(0)
    time.clock_settime(0,local_time_correction)
    print('corrected local time by adding %f' % time_correction)
    log('corrected local time by adding %f' % time_correction)
    ask_shutdown() # will call subprocess 'sudo shutdown now'
    exit()

#plot_oof(oof_history)
#plot_data()
#plot_mic_data(values)
#plot_data()
#plot_flutter_data(flutter_data[13],accel_max =200)

def bottom():
    return
