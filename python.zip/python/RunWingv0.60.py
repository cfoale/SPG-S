thisfilename = 'RunWingv0.60.py'
#4/7/2021 MAJOR CHANGE - WING becomes CLIENT to TAIL
#3/25/2021 added simulation, removed mcp read for bFlight = False.
#moving_average =1 (was 2)
#note we skipped RunWingv0.41.py, 0.31 -> 0.51
#10/27/2020 updated model to use Ax,Ay,Az, dPz, dPy, dPx without P, added Az
#4/28/2020 add bluetooth_power_cycle() to main loop monitoring
#quit 
#exit()

bFlight = True  #affects low voltage detection, oof sending
def top():
    return

global bt_addr1 #tail bluetooth MAC address
if bFlight:
    bt_addr1= 'B8:27:EB:85:DA:78'#  'B8:27:EB:81:A2:BF'
else:
    bt_addr1 = 'B8:27:EB:A6:AD:BC' # sim tail pizero 2/6/2020
    # rpi0wsim address is B8:27:EB:9B:11:80
global cockpit_port #bluetooth sockets port
cockpit_port = 0x1005  # must be a different odd number

global alpha_limt,tipping_limit,vrel_limit,flutter_limit,speak_stall_limit,blue_tooth_fail_count_limit
tipping_limit = 1.8
vrel_limit = 560 #VNE
alpha_limit =666 #shows on OLED
speak_stall_limit = 630 #deep alpha
flutter_limit = 180 #
#downdraft limits reference flight 4/2/2021
wzt_limit = 0.10 #turning in thermal was 0.15
dwxt_limit = 0.5 #large tipping event had 0.7
downdraft_limit = 1.5 #2.0 was the largest excursion while thermalling.  = dwyt*dazt*ddpy/10
surge_limit = downdraft_limit/3
surge_dwxt_limit = 0.24*dwxt_limit #large tipping event had 0.7

blue_tooth_fail_count_limit = 1000000

import subprocess # for speaking
import time
import datetime
import math
import numpy as np
import bluetooth
import time
from struct import Struct
from struct import calcsize
import threading

import tensorflow as tf
from tensorflow import keras
############################ SPI MCP3008 initialization ###############################
# files SP.py MCP3.py GPI.py are in this directory, so that SPI fetch frequency can be changed
# Adafruit_GPIO must be system wide installed from
# https://github.com/adafruit/Adafruit_Python_MCP3008
import Adafruit_GPIO as GPIO  # for switch and LED monitoring
from SP import SpiDev  
from MCP3 import MCP3008
######### mcp is object to get values from SPI MCP3008 ########################
SPI_PORT   = 0
SPI_DEVICE = 0
#uses SpiDev, 1.8 ms/8 reads at 500000 Hz (in SP.py)
global mcp
mcp = MCP3008(spi=SpiDev(SPI_PORT, SPI_DEVICE))

global time_correction, bluetooth_fail_count, low_voltage_count_limit
low_voltage_count_limit = 20
time_correction = 0 # server_time - local time used to update clock after main_loop

low_voltage_count = 10 # this is monitored in the main_loop to determine if shutdown is required
if bFlight:
    low_voltage_value = 530 # channel 8 from the mcp3008 - 530 = 3.5V for flight
else:
    low_voltage_value = 0
    
speaker_id = '00:E0:4C:6A:B1:B9' # bluetooth device id of the cantor speaker
bluetooth_fail_count = 0 #if this exceeds 2, the main loop will call power cycle

def increment_log_number():
    lognumber = np.load('./lognumber.npy')
    lognumber[0] = lognumber[0]+1
    np.save('./lognumber',lognumber)
    return lognumber[0]

lognumber = increment_log_number() #increment_log_number()
datafilepathA = time.strftime('./SPG-Flight/all%Y_%m_%d_') + str(lognumber)+str('.dat')
datafilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('.dat')
annunciatefilepath = time.strftime('./SPG-Flight/annunciate%Y_%m_%d_') + str(lognumber)+str('.dat')
logfilepath = time.strftime('./SPG-Flight/%Y_%m_%d_') + str(lognumber)+str('_log.txt')

def bluetooth_power_cycle():
    global bluetooth_fail_count
    bluetooth_fail_count = 0
    print('bluetooth power cycle code disabled')
    log('bluetooth power cycle code disabled')
    return
    print('bluetooth_power_cycle')
    log('bluetooth_power_cycle')
    cmd = 'sudo rfkill block bluetooth'
    subprocess.call(cmd, shell=True)
    time.sleep(5)
    cmd = 'sudo rfkill unblock bluetooth'
    subprocess.call(cmd, shell=True)
    return

def play_thread_function():
    global speaker_id,playfilepath
    cmd = 'aplay -D bluealsa:SRV=org.bluealsa,DEV=' + speaker_id + ' '+ playfilepath 
    log(cmd)
    print(cmd)
    subprocess.call(cmd, shell=True)
    return

global playfilepath
def play(file):
    global speaker_id, playfilepath
    playfilepath = file # can add a path to the files here
    play_thread = threading.Thread(target=play_thread_function, args=())
    play_thread.daemon = True  # so it will die on exit
    play_thread.start() 
    return
    
global last_speak_time,phrase #used by speak_thread_func
last_speak_time = time.clock_gettime(0)
def speak(annunciate, nodelay=False):
    global phrase, last_speak_time
    if nodelay:
        last_speak_time = time.clock_gettime(0)-6
    log(annunciate) #log all occasions even if not sounded   
    if (time.clock_gettime(0) - last_speak_time) > 5:
        phrase = annunciate
        speak_thread = threading.Thread(target=speak_thread_function, args=())
        speak_thread.daemon = True  # so it will die on exit
        speak_thread.start()
        last_speak_time = time.clock_gettime(0)
        
    if not bFlight:
        print(phrase)
    return

def speak_thread_function():
    global speaker_id,phrase
    cmd = 'espeak "' # single quotes on the outside of a string, double quotes inside
    cmd = cmd + phrase + '" --stdout | aplay -D bluealsa:SRV=org.bluealsa,DEV='+ speaker_id 
    subprocess.call(cmd, shell=True)
    time.sleep(2)
    return

def prompt(index):
    #play('out.wav')
    if index == 0:
        play('ax.wav')
    if index == 1:
        play('ay.wav')
    if index == 2:
        play('beta.wav')
    if index == 3:
        play('alpha.wav')
    if index == 4:
        play('vrel.wav')
    if index == 5:
        play('p.wav')
    return

def check_voltage(val) : # val is td[8] called from read_mcp3008
    # if the voltage is below 530 threshold, the incidence counter increases.  3 or more means
    # 3 or more successive measurements show low voltage. If it was noise, the next measure resets
    global low_voltage_count
    global low_voltage_value
    if val < low_voltage_value : 
        low_voltage_count = low_voltage_count + 1
        print('low voltage '+str(val)) # action is taken in main_loop
    else :
        low_voltage_count = low_voltage_count - 1
    if low_voltage_count < 0:
        low_voltage_count = 0
    return

def log(line):
     out=open(logfilepath,'a')
     date=datetime.datetime.now()
     out.write(str(date))
     out.write(': ')
     out.write(line)
     out.write('\n')
     out.close()

def read_mcp3008():
    global datafile,tstart,mcp #handle opened in main_loop to the local wing data storage
    # Read all the ADC channel values in a list.
    td = [0.0]*9 #makes list with 8 floating point zeros
    td[0] = time.clock_gettime(0) - tstart
    
    if not bFlight: #simulate
        simfreq = 2*3.14*(1/60) # every 60s
        td[1] = 500 + np.random.randint(-5,5) #Ax
        td[2] = 400 + np.random.randint(-80,80) #Ay
        td[3] = 510 + np.random.randint(-5,5) # Az
        td[4] = 810 + np.random.randint(-10,10) #beta
        td[5] = 690 + (660-740)*np.sin(simfreq * td[0]) + np.random.randint(-40,40) #alpha
        td[6] = 650 +  0.5*(810-515)*np.sin(simfreq * td[0]) + np.random.randint(-10,10) #vrel
        td[7] = 730 - 50*td[0]/360 + np.random.randint(-10,10)#pressure
        td[8] = 610 - 100*td[0]/360 + np.random.randint(-20,20)#1 hr battery
    else:
        for j in range(8):
        # The read_adc function will get the value of the specified channel (0-7).
            td[j+1] = mcp.read_adc(j)
        
    for listitem in td: # chnage this to td to record all the time and 8 channels
        datafile.write('%s ' % listitem)
        
    val = td[8]
    check_voltage(val) #this has to be called in read_mcp3008 as voltage channel is discarded on return
    
    datafile.write('\n')
    return [td[0],td[1],td[2],td[3],td[4],td[5],td[6]] # t,  Ax, Ay,Az, beta, alpha, vrel

def update_block(dt,block,datazero,data_history_for_mav=[], moving_average = 1): # act first, then sleep dt
    vals = read_mcp3008() # returns time, and the selected channels (7 values)
    if moving_average > 1: #we need to compute moving average before adding to the block
        data_history_for_mav.pop(0)
        data_history_for_mav.append(vals)
        mav_vals = np.transpose(mav(np.transpose(data_history_for_mav),moving_average))[0]
        #print('mav_vals ' + str(mav_vals))
        block.pop(0)
        block.append(normalize(mav_vals[1:],datazero))
    else:
        block.pop(0)
        block.append(normalize(vals[1:],datazero))
        #print(vals)
    time.sleep(dt)
    return vals

def mav(data_by_row,N):
    x = data_by_row[0] #time is first row, which should not be averaged
    rmlength = len(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    rm = []
    rm.append(np.array(data_by_row[0][0:rmlength]))
    for j in range(1,np.shape(data_by_row)[0]):
        x = data_by_row[j]
        rm.append(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    return rm

# make a function to normalize a single line from the import
# requires global datazero to have been calculatated
def normalize(channels,datazero):
    channel_range = 1024 # a characteristice range of data values, min to max
    rv = []
    for idx in range(0,len(channels)):
        rv.append((channels[idx] - datazero[idx]) / channel_range)
    return rv

def GetDataZero(data,number_of_takes=49): #cmf - we should only do this once, if we are running an online prediction
    # Get mean of first 50 samples and store value 
    dz = []
    for idx in range(1, np.shape(data)[1]):
        dz.append(np.mean(data[0:number_of_takes, idx]))
    return dz

def onepair(nd,params): # nd is noddata from the preceding 'period' rows, with the 'period+1'th
    #expecting period + 1 rows
    td = np.array(nd).copy() # so we do not pollute nd refference
    td = np.transpose(td).tolist() #now period + 1 columns
    instances = []
    labels = []
    period = params['period']
    inst = []
    labl = []
    for ch in range(0,params['num_channels']):
        inst.append(td[ch][:period])         
        labl.append(td[ch][period])
    instances.append( [item for sublist in inst for item in sublist]) # flatten the list
    labels.append(labl)
    return instances, labels

def out_of_family(t, p, params, oofmax):
    nchannels = params['num_channels']
    oof = np.empty((0,nchannels), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nchannels], float)
        for ch in range(0,nchannels): # the channels
            val = math.sqrt((t[idx][ch] - p[idx][ch])*(t[idx][ch] - p[idx][ch]))
            channels[0,ch] = val / oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def signed_out_of_family_over_max(t, p,params,oofmax):
    nfeatures = params['num_channels']
    oof = np.empty((0,nfeatures), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nfeatures], float)
        for ch in range(0,nfeatures): # the channels
            val = (t[idx][ch] - p[idx][ch])
            channels[0,ch]=val/oofmax[ch]
        oof = np.append(oof,channels,axis=0)
    return oof

def plot_oof(t):
    import matplotlib.pyplot as plt #slow load
    plt.plot(t)
    plt.grid(True)
    #plt.gca().set_ylim(0,0.5)
    plt.ion()
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)

def plot_data(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    '''imports data as np.array'''
    data = np.loadtxt(datafilepath)
    if finish_idx == 0:
        finish_idx = len(data)
    rawchannels = np.shape(data)[1]
    data = np.transpose(data[start_idx:finish_idx])
    times = data[0] # save for separate plot
    data = np.transpose(data[1:rawchannels]) #drop the time values in first row
    fig0 =plt.figure(0)
    fig0.suptitle(datafilepath)
    ax=fig0.add_subplot(211)
    ax.set_title('Raw data beginning at ' + str(start_idx))
    ax.plot(data,label=['Ax', 'Ay', 'Az', 'dpz', 'dpy', 'dpx','P','V'])
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Ax', 'Ay', 'Az', 'dpz', 'dpy', 'dpx','P','V'])
    ax.grid(True)
    # plot times and intervals
    intervals = [0]
    for i in range(1,len(times)):
        intervals.append((times[i] - times[i-1])*1000)
    ax2=fig0.add_subplot(212)
    ax2.plot(list(range(start_idx,finish_idx)),times,list(range(start_idx,finish_idx)),intervals,label=['time','intervals'])
    ax2.legend(handles, ['time (s)','intervals (ms)'])
    ax2.grid(True)
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=True)
    return
    
def gpio_callback(pin):
    global bcontinue
    print('called back..' + str(pin))
    if gpio.is_high(22):
        print('GPIO 22 is high - quitting')
        log('GPIO 22 is high - quitting')
        gpio.remove_event_detect(22) # so a subsequent push to shutdown fully does not trigger this
        bcontinue = False
        gpio.output(17,GPIO.LOW)  # sets LED off
        
def ask_shutdown() :
    #speak("press push button to shutdown in 10 seconds")
    time.sleep(2) # so we have time to un press
    for i in range(0,10):
        pb = gpio.input(22)
        print("pb is "+str(pb))
        if pb != 0 :
            print('shutting down')
            log('shutting down')
            subprocess.call('sudo shutdown now', shell=True)
        time.sleep(1) # can be subprocess call to shutdown

# this adapter is hci0    B8:27:EB:9B:11:80 WING
def make_socket_listen():  #listens for cockpit
    global cockpit_port
    print("make_socket_listen for cockpit.")
    server_sock=bluetooth.BluetoothSocket( bluetooth.L2CAP )
    port = cockpit_port
    server_sock.bind(("",port))
    server_sock.listen(1)
    return server_sock

def close_sockets(client_sock, server_sock):
    client_sock.close()
    server_sock.close()
    print('bluetooth sockets closed')
    log('bluetooth sockets closed..')
    return

def bluetooth_server_thread_function(): #connects to cockpit
    global bcontinueserverthread, datagramindex,datagram, tstart, time_correction
    global bluetooth_fail_count
    print("Launching bluetooth server thread")
    log('Launching bluetooth server thread')
    while bcontinueserverthread:
        try:
            server_sock = make_socket_listen()
            client_sock,address = server_sock.accept()
            print("Accepted connection from ",address)
            log('Accepted connection from '+ str(address))
            break
        except bluetooth.BluetoothError as e:
            print("unable to accept connection from "+str(address))
            close_sockets(client_sock, server_sock)
            time.sleep(1)

    #get setup to receive server time as double precision
    server_time_format = '1d' #'1d' is struct format for double, unlike %
    server_time_struct = Struct(server_time_format)
    timegramformatsize = calcsize(server_time_format)
    #receive the server time as 8 bytes, and set it
    data = client_sock.recv(timegramformatsize)
    try:
        server_time = server_time_struct.unpack(data)[0] #returned value is a tuple
        time_correction = server_time - time.clock_gettime(0)
        print('server - local time is %f' % time_correction)
        log('server - local time is %f' % time_correction)

    except struct.error as e:
        print('Unable to receive server time..link failed')
        log('Unable to receive server time..link failed')

    #send the first datagram with the start time
    timegram = server_time_struct.pack(tstart)
    print('sending start time')
    log('sending start time')
    try:
        sent = client_sock.send(timegram)
        print('sent %d bytes, Start Time %f' % (sent, tstart))
        log('sent %d bytes, Start Time %f' % (sent, tstart))
    except bluetooth.BluetoothError as e:
        print("timegram failed")
        log('sending start time failed')

    ncount = 0
    olddatagramindex = 0 #not in the main range
    while bcontinueserverthread:
        if olddatagramindex != datagramindex:
            ncount = ncount + 1
            try:
            # b = bytes('foo.bar', 'utf8') # lets you specify a string to become bytes b
                #datagram = MyStruct.pack(datagramindex, False, 42.0,b'char data')
                sent = client_sock.send(datagram)
                olddatagramindex = datagramindex
                #sent = client_sock.send('Datagram  => ' + str(ncount))
                #print("sent %d bytes, index %d" % (sent, datagramindex))
            except bluetooth.BluetoothError as e:
                print("connection failed")
                bluetooth_fail_count = bluetooth_fail_count + 1
                time.sleep(1)
                close_sockets(client_sock, server_sock)
                time.sleep(1)
                server_sock = make_socket_listen()
                client_sock,address = server_sock.accept()
                print("Accepted connection from ",address)
                log('Accepted connection from '+ str(address))
                #receive the server time as 8 bytes, and set it
                data = client_sock.recv(timegramformatsize)
                try:
                    server_time = server_time_struct.unpack(data)[0] #returned value is a tuple
                    time_correction = server_time - time.clock_gettime(0)
                    print('server - local time is %f' % time_correction)
                    log('server - local time is %f' % time_correction)
                
                except struct.error as e:
                    print('Unable to receive server time..link failed')
                    log('Unable to receive server time..link failed')

                #print("First Data received: ", str(data))
                #send the first datagram with the start time
                #timegram = datagram  #we do not want to pollute the original
                #timegram = MyStruct.pack(0, tstart,0,0,0,0,0,0,0,0,0,0,0,0)
                timegram = server_time_struct.pack(tstart)
                print('sending start time')
                try:
                    sent = client_sock.send(timegram)
                    print('sent %d bytes, Start Time %f' % (sent, tstart))
                    log('sent %d bytes, Start Time %f' % (sent, tstart))
                except bluetooth.BluetoothError as e:
                    print("timegram failed")
                    log('sending start time failed')
        time.sleep(.05) # faster than the main loop 2/10/2020 0.01 to 0.05
    print("Terminating bluetooth server thread")
    log('Terminating bluetooth server thread')
    return

def connect_socket_tail():
    #datagramsize = 48 # minimum #calcsize('i?f9s')
    #print('datagram size %d' % datagramsize)
    #bluetooth.set_l2cap_mtu(sock1, datagramsize)
    global i1,d1,o1,bTail,bt_addr1
    bTail = False #tail thread has started
    port1 = 0x1001
    datagramformat = 'i29f'
    MyStruct = Struct(datagramformat)
    datagramformatsize = calcsize(datagramformat)
    #create a time datagram to send the local time to tail
    timegramformat = '1d' #'1d1 is struct format for a double, unlike %
    timestruct = Struct(timegramformat)
    timegramformatsize = calcsize(timegramformat)
    
    sock1=bluetooth.BluetoothSocket(bluetooth.L2CAP)
    try:
        print("trying to connect to %s on PSM 0x%X" % (bt_addr1, port1))
        log("trying to connect to %s on PSM 0x%X" % (bt_addr1, port1))
        sock1.connect((bt_addr1, port1))
        localtime = time.clock_gettime(0)
        timegram = timestruct.pack(localtime)
        print('sending tail timegram %f' % localtime)
        log('sending tail timegram %f' % localtime)
        sock1.send(timegram)
        #sock1.send("go")
        print("connected to Tail.  Receiving..")
        log("connected to Tail.  Receiving..")
        speak('Tail connected!',nodelay = True)
        bTail =  True
    except bluetooth.BluetoothError as e:
        print('unable to connect to Tail..')
        log('unable to connect to Tail..')
        bTail = False
    #initialize tail IFI lists
    #d1 = [0.0]*7
    #o1 = [0.0]*6
    #i1 = 0
    #gather datagrams
    data1 = b''
    datagram = b''
    #the first datagram sent should contain the start time, so log this
    try:
        data1 = sock1.recv(timegramformatsize) # blocking       if len(list(data1)) == datagramformatsize:
        if len(list(data1)) == timegramformatsize:
            i1_0 = 0
            start_timeT = 0.0
            start_timeT = timestruct.unpack(data1)
            #(i1_0,start_timeT, d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],o1[0],o1[1],o1[2],o1[3],o1[4],o1[5]) = MyStruct.unpack(data1)
            log('Tail start time:')
            logtimetext = '%f' % (start_timeT)
            log(logtimetext)
            print('Tail Start time %f' % start_timeT)
        
    except bluetooth.BluetoothError as e:
            sock1.close()
            print('tail server closed prematurely..')
            log('tail server closed prematurely..')
            bTail = False
        
    while bTail:
        #time.sleep(0.1) #to let the calling thread execute
        try:
            data1 = sock1.recv(datagramformatsize) # blocking
            if len(list(data1)) == datagramformatsize:
                datagram = MyStruct.unpack(data1)
                #print("sock1 datagram")
                (i1,d1[0],d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],d1[7],d1[8],d1[9],d1[10],d1[11],d1[12],d1[13],d1[14],
                o1[0],o1[1],o1[2],o1[3],o1[4],o1[5],o1[6],o1[7],o1[8],o1[9],o1[10],o1[11],o1[12],o1[13]) = datagram
                #print('index %i\n%s\n%s' % (i1, d1, o1))
                #print('tail index %i' % i1)
            else :
                bTail = False # bad data
                sock1.close()
                print('bad Tail data..')
                log('bad Tail data..')
            #print("sock1 received: %s" % data1)
        except bluetooth.BluetoothError as e:
            sock1.close()
            print('Tail server closed prematurely..')
            log('Tail server closed prematurely..')
            bTail = False
    #if bTail: #if for some reason the exception did not do this    
        #sock1.close()
    print('tail thread terminated')
    log('tail thread terminated')
    return

def connect_local_wing():
    global i2,d2,o2,bWing,datafilepath
    global oofmax, bcontinue, datafile
    global oof_history
    global tstart
    bWing = True #wing thread has started
    ############################ initialize the TensorFlow TF2 model parameters
    moving_average = 1 #Average current point with 3 previous measurements - this effects import_data
    modelfilepath = './SPG-Flight/2020_10_23_modelv6.h5'
    oofmaximumsfilepath = './SPG-Flight/2020_10_23_oof_max.npy'

    datazero = [522.8163265306123,
     398.5204081632653,
     509.6530612244898,
     821.6173469387755,
     792.8316326530612,
     819.0102040816327]

    params = {
        'hfactor': 1,
        'num_channels': 6,
        'period': 16,
        'num_hidden_layers': 1,
        }
    datazerosize = 49
    
    wing_count = 1 # a counter to estimate local cockpit data loop time
    tstart_wing = time.clock_gettime(0)
    ######################## period data for TF model #######################################
    blocksize = params['period'] + 1
    block = [[0.0]*(params['num_channels'])]*blocksize # will be blocksize rows x num channels columns of noddata
    ################initialize the history for moving average###############################
    data_history_for_mav=[[0.0]*(1+params['num_channels'])]*(moving_average + 1) # we will take the penultimate value of mav()
    ###################### timing #############################
    # get a block of data at a regular interval dt
    dtoh = 0.127 # execution overhead is dependent on code
    dt0 = 0.250 # data interval desired
    dt = dt0 - dtoh # is what we pass to sleep()
    # Get datazerodata - better if it can be determined from previous data
    datazerodata = []
    datafile = open(datafilepath,'w')
    for i in range(0,datazerosize):
        if not bFlight: #simulate
            td = 9*[0]
            simfreq = 2*3.14*(1/60) # every 60s
            td[0] = i #simulates time
            td[1] = 500 + np.random.randint(-5,5) #Ax
            td[2] = 400 + np.random.randint(-40,40) #Ay
            td[3] = 510 + np.random.randint(-5,5) # Az
            td[4] = 810 + np.random.randint(-20,20) #beta
            td[5] = 720 - np.sin(simfreq * td[0]) + np.random.randint(-20,20) #alpha
            td[6] = 690 + np.sin(simfreq * td[0]) + np.random.randint(-20,20) #vrel
            td[7] = 730 - 50*td[0]/3600 + np.random.randint(-20,20)#pressure
            td[8] = 610 - 100*td[0]/3600 + np.random.randint(-20,20)#1 hr battery
            values = td[0:7]
        else:
            values = read_mcp3008() # this sleeps for time dt, uses datafile handle
        datazerodata.append(values)
        time.sleep(dt)
        
    datafile.close()  #zero data recorded
    ############################ load the model #############################
    model = keras.models.load_model(modelfilepath)
    print('wing modelfilepath %s' % modelfilepath)
    log('wing modelfilepath %s' % modelfilepath)
    print('wing datafilepath %s' % datafilepath)
    log('wing datafilepath %s' % datafilepath)
    new_datazero = GetDataZero(np.array(datazerodata),datazerosize) # GetDataZero expects numpy array
    print('new datazero is ' + str(new_datazero))
    log('new datazero is ' + str(new_datazero))
    log('datazero assigned '+ str(datazero))
    #datazero = new_datazero
    print(str(datazero))
    print('normalize new_datazero')
    log('normalize new_datazero')
    normalized_datazero = normalize(new_datazero,datazero)
    print(normalized_datazero)
    log(str(normalized_datazero))
    oofmax = np.load(oofmaximumsfilepath) # must be read in as initialization
    print('OOF maximums ' + str(oofmax))
    log('OOF maximums ' + str(oofmax))
    log('starting main loop .. ')
    
    datafile = open(datafilepath,'a') # updated in update_block(), must be closed after thread termination
    #oof_history = []
    log('wing start time %f' % tstart_wing)
    oofcount = 0
    maxoofcount = 3 #use?
    
    while bWing:
        # get the update and write the new row to the data file
        d2 = update_block(dt, block,datazero,data_history_for_mav,moving_average) #sleeps dt, returns time, plus 6 values
        inst, t = onepair(block,params)

        p = model.predict_on_batch((inst,t)).numpy().tolist()
        o2 = signed_out_of_family_over_max(t, p,params,oofmax)[0]

        #update the index so the main loop will consider a new point
        i2= i2 + 1
        wing_count = wing_count + 1  #yes, this is the same as i2, but is used to calculate cycle time
        #oof_history.append(oof)

    tend = time.clock_gettime(0)
    interval = (tend - tstart_wing)/wing_count
    datafile.close()
    print("wing 6 channel read time (s) " + str(interval))
    log('wing 6 channel read time (s) ' + str(interval))   
    print('wing thread terminated')
    log('wing thread terminated')
    return

def start_placeholder(): # a dummy function to navigate to following executable statements f
    return
############################### executable statements ###########################
print(thisfilename)
log(thisfilename)
# setup a GPIO monitoring of switch and LED
gpio = GPIO.get_platform_gpio()  # determines if BeagleBone or Raspberry Pi
# set an event that sleeps until pin 22 switch goes high
gpio.setup(22,GPIO.IN,GPIO.PUD_DOWN) # our switch interface
gpio.setup(17,GPIO.OUT) # our green LED interface
bouncetime = 500 #100 ms
#setup server that writes data to cockpit
global bcontinueserverthread, datagramindex, datagram, MyStruct, tstart
bcontinueserverthread = True
datagramindex = 0 # this is initialized in server thread as well, so datagram considered sent already
datagramformat = '2i42f' #for the wing and tail

MyStruct = Struct(datagramformat) # used to pack the datagram
#datagram = MyStruct.pack(datagramindex,0.,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0,.0)

#initialize tstart before the bluetooth server, as it sends tstart
tstart = time.clock_gettime(0)
bluetooth_thread = threading.Thread(target=bluetooth_server_thread_function, args=())
bluetooth_thread.daemon = True  # so it will die on exit
bluetooth_thread.start()

# define main loop actions, repeatable
def main_loop(bprint = False, duration=18000):
    global oof_history, datafile
    global bcontinue
    global low_voltage_count, bluetooth_fail_count,low_voltage_count_limit
    global datagramindex, datagram
    global tstart
    ####################from cockpit##################
    global bcontinue, oof_array3x6, bluetooth_fail_count, bluetooth_failure_count_limit
    global alpha_limit,vrel_limit, tipping_limit, flutter_limit,speak_stall_limit
    bcontinue = True
    main_loop_dt = 0.2 # this is the saving interval for all data
    print('starting main loop with dt = %f' % main_loop_dt)
    log('starting main loop with dt = %f' % main_loop_dt)
    #tail data used to be initalized in connect_socket_tail
    global i1,d1,o1, bTail
    d1 = [0.0]*15
    o1 = [0.0]*14
    old_i1 = 0
    i1 = 0
    #wing data used to be initialized in connect_socket_wing
    global i2,d2,o2, bWing, d, o #wing values from connect_local_wing
    #initialize tail IFI lists
    #variables assigned in connect_local_wing, to be copied to d2 and o2 for transmission
    d2 = [0.0]*7
    o2 = [0.0]*6
    old_i2 = 0
    i2 = 0
    
    bTail = False
    bWing = False
    wing_thread = threading.Thread(target=connect_local_wing, args=())
    wing_thread.daemon = True  # so it will die on exit
    wing_thread.start()
    time.sleep(5) # let bluetooth threads execute
    
    tail_thread = threading.Thread(target=connect_socket_tail, args=())
    tail_thread.daemon = True  # so it will die on exit
    tail_thread.start()
    time.sleep(5) #let bluetooth threads execute
    #########################################end of cockpit code
    print('bTail %d, bWing %d' % (bTail, bWing))
    log('bTail %d, bWing %d' % (bTail, bWing))
    log('main loop start time %f' % tstart)
    speak("START",nodelay=True)
    npoints = 0
    gpio.output(17,GPIO.HIGH)  # sets LED on
    # set an event that sleeps until pin 22 switch goes high
    gpio.add_event_detect(22, GPIO.RISING, gpio_callback, bouncetime)
    
    #ASSEMENT initialization
    tipping = 0
    downdraft = 0
    #initialize tipping differentials   
    dpy_last = d2[5]
    ayw_last = d2[2]
    dwxtail = 0
    dayw = 0
    ddpy = 0
    tipping = 0
    #initialize downdraft differentials
    wyt_last = d1[7]
    azt_last = d1[3]
    wzt = d1[8]
    dwyt = 0
    dazt = 0
    downdraft = 0
    #######################
    tlastupdate = tstart
    loopcount = 0
    bcontinue = True
    while bcontinue is True:
        #see if we have data from wing or tail or cockpit
        time.sleep(main_loop_dt/10) #check 10 x the rate of data
        tnow = time.clock_gettime(0)
        tsincestart = tnow - tstart
                ####################### TAIL WING ASSESSMENT###########################
        #each of the 2 box's index changes store data ONLY IF IT HAS CHANGED - covers speaking as priority
        if bTail:
            if i1 != old_i1:
                old_i1 = i1
                #tipping     #only update differentials for tail         
                dwxtail = d1[9]
                #downdraft # only update differentials for tail
                dwyt = d1[7] - wyt_last
                dazt = d1[3] - azt_last
                wyt_last = d1[7]
                azt_last = d1[3]
                wzt = d1[8]
                #process tail flutter PRIORITY
                if bWing: #calculate flutter is 1st priority
                    #calculate CubeRoot(Wax4*Waz4*Vrel)
                    fl = np.cbrt((830 - int(d2[6]))*o1[3]*o1[10]) #o1 is zero based
                    if fl > flutter_limit:
                        speak("TAIL")
                        if not bFlight:
                            print("TAIL %f" % fl)
                    
                    tipping = (dwxtail * ddpy *dayw)/1000.0
                    #speak tipping
                    if tipping > tipping_limit:
                        speak("LEFT!")
                    
                    elif tipping < (-tipping_limit):
                        speak("RIGHT!")
                    
                    ##downdraft assessment
                    downdraft = dwyt*dazt*ddpy/10
                    if downdraft < (-downdraft_limit): #going down
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if np.abs(dwxtail) < dwxt_limit: #not rolling
                                speak("LEAVE")
                        #turning left
                        if wzt < (-wzt_limit): #going left
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                speak("CLOSE")
                            if dwxtail < (-dwxt_limit): #increasing left
                                speak("LEAVE")
                            if dwxtail > dwxt_limit: #decreasing left
                                speak("CLOSE")
                        #turning right
                        if wzt > wzt_limit: #going right
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                speak("CLOSE")    
                            if dwxtail < (-dwxt_limit): #decreasing bank
                                speak("CLOSE")
                                
                    if downdraft > surge_limit: #going up
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if dwxtail > surge_dwxt_limit: #rolling right
                                speak("LEFT")
                            if dwxtail < (-surge_dwxt_limit): #rolling right
                                speak("RIGHT")
                
        if bWing: #fast response TIPPING is priority after FLUTTER
            if i2 != old_i2:
                old_i2 = i2
                #tipping #only update differentials for wing
                ddpy = d2[5] - dpy_last 
                dayw = d2[2] - ayw_last
                dpy_last = d2[5]
                ayw_last = d2[2] 
                if bTail:
                    tipping = (dwxtail * ddpy *dayw)/1000.0
                    if tipping > tipping_limit:
                        speak("LEFT!")
                    
                    elif tipping < (-tipping_limit):
                        speak("RIGHT!")
                    
                    ##downdraft assessment
                    downdraft = dwyt*dazt*ddpy/10
                    if downdraft < (-downdraft_limit): #going down
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if np.abs(dwxtail) < dwxt_limit: #not rolling
                                speak("LEAVE")
                        #turning left
                        if wzt < (-wzt_limit): #going left
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                speak("CLOSE")
                            if dwxtail < (-dwxt_limit): #increasing left
                                speak("LEAVE")
                            if dwxtail > dwxt_limit: #decreasing left
                                speak("CLOSE")
                        #turning right
                        if wzt > wzt_limit: #going right
                            if np.abs(dwxtail) < dwxt_limit: #no change in bank
                                speak("CLOSE")    
                            if dwxtail < (-dwxt_limit): #decreasing bank
                                speak("CLOSE")
                                
                    if downdraft > surge_limit: #going up
                        #straight
                        if np.abs(wzt) < wzt_limit: #going straight
                            if dwxtail > surge_dwxt_limit: #rolling right
                                speak("LEFT")
                            if dwxtail < (-surge_dwxt_limit): #rolling right
                                speak("RIGHT")
                        
                #display alpha and vne on wing row of OLED
                        
                alpha = int(d2[5]) #d2[0] has wing time, so parameters shifted right
                vrel = int(d2[6]) #
                if vrel < 806 and alpha < alpha_limit:
                    #if not bFlight:
                        #print('alpha')
                    if alpha < speak_stall_limit:
                        speak("PUSH")
                        
                elif vrel < vrel_limit:
                    speak("PULL")
                    
        ###############send the wing data by bluetooth server to cockpit
        datagramindex = datagramindex + 1
        # MyStruct has been formatted at start to be 'i13f'
        datagram = MyStruct.pack(datagramindex,bTail, d2[0],d2[1],d2[2],d2[3],d2[4],d2[5],d2[6],
                                     o2[0],o2[1],o2[2],o2[3],o2[4],o2[5],
                                 d1[0],d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],d1[7],d1[8],d1[9],d1[10],d1[11],d1[12],d1[13],d1[14],
                                 o1[0],o1[1],o1[2],o1[3],o1[4],o1[5],o1[6],o1[7],o1[8],o1[9],o1[10],o1[11],o1[12],o1[13])

        time.sleep(0.05) # pause to let bluetooth server thread send,
                
        if low_voltage_count > low_voltage_count_limit :
            bcontinue = False
            log('low_voltage!')
            speak('LOW VOLTAGE!')
            subprocess.call('sudo shutdown now', shell=True)
            
        if bluetooth_fail_count > blue_tooth_fail_count_limit :  #bluetooth connection trouble shooting
            bluetooth_power_cycle_thread = threading.Thread(target=bluetooth_power_cycle, args=())
            bluetooth_power_cycle_thread.daemon = True  # so it will die on exit
            bluetooth_power_cycle_thread.start()
            
        npoints = npoints + 1  # a stop point if the h/w stop switch is not used
        if tnow-tstart > duration : #quit if we exceeded running time
            bcontinue = False
                       
        #####################################################
        #STORE ALL DATA into datafileA EVEN IF STATIC (main_loop_dt = 250 ms)
        if (tnow - tlastupdate) >= main_loop_dt:
            tlastupdate = tnow
            #update the loop count and save the states       
            loopcount = loopcount+1
            #store all our data in one file, with the local time since start
            taildata = str('%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f  '
                % (tsincestart,d1[1],d1[2],d1[3],d1[4],d1[5],d1[6],d1[7],d1[8],d1[9],d1[10],d1[11],d1[12],d1[13],d1[14],
                o1[0],o1[1],o1[2],o1[3],o1[4],o1[5],o1[6],o1[7],o1[8],o1[9],o1[10],o1[11],o1[12],o1[13]))
            
            wingdata = '%f %f %f %f %f %f %f %f %f %f %f %f\n'  % (d2[1],d2[2],d2[3],d2[4],d2[5],d2[6],
                                                                   o2[0],o2[1],o2[2],o2[3],o2[4],o2[5])
            #if bWing and bTail and not bFlight:
                #print('tipping %f' % tipping)
                #print('downdraft %f' % downdraft)
                    
            alldata = taildata + wingdata 
            #print('alldata ' + str(alldata))
            datafileA = open(datafilepathA,'a')
            datafileA.write(alldata)
            datafileA.close()
        #try to reconnect if  btail is false after 60s
            if loopcount % 60 == 0:
                if bTail == False:
                    bluetooth_fail_count = bluetooth_fail_count + 1
                    old_i1 = 0
                    i1 = 0
                    tail_thread = threading.Thread(target=connect_socket_tail, args=())
                    #tail_thread.daemon = True  # so it will die on exit
                    tail_thread.start()
                    time.sleep(.01) #let threads execute
                    print('retrying tail connect ')
                    log('retrying tail connect ')    
            #classify(tsincestart,d1,o1,d2,o2,d3,o3) #add to history, evaluate N,S,V,L,R and annunciate
    # finish up
    tend = time.clock_gettime(0)
    print("main loop cycle time (s) %f" % ((tend - tstart)/npoints))
    log("main loop cycle time (s) %f" % ((tend - tstart)/npoints))
    print("all data recording time (s) %f" % ((tend - tstart)/loopcount))
    log("all data recording time (s) %f" % ((tend - tstart)/loopcount))
    gpio.remove_event_detect(22)
    gpio.output(17,GPIO.LOW)  # sets LED off
    return

if bFlight:
    main_loop(False, duration = 3600*5) #5 hours max 3600*5
else:
    main_loop(False, duration = 300) #5 minutes
    
bcontinueserverthread = False
bWing = False
bTail = False
print('bluetooth to cockpit server finishing')
log('bluetooth to cockpit Server finishing')
time.sleep(5)
#set the time to be that of the server
local_time_correction = time_correction + time.clock_gettime(0)
if bFlight:
    time.clock_settime(0,local_time_correction)
    print('corrected local time by adding %f' % time_correction)
    log('corrected local time by adding %f' % time_correction)
speak('STOPPING')
ask_shutdown()
exit()

#plot_oof(oof_history)
#plot_data()

def bottom():
    return

