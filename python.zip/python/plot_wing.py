## Open 6+8 channels  SPGTail Test 2-11-2020  dat file and show its dataT with SPGWing dataW
## RunTailv0.1.py   RunWingv0.1.py
## Solo UFM - 15.    flight with Cockpit IFI gathering data.
# The data from the Tail and the Wing was continuous, after disabling the 1 - wire daemon in Wing,
# and fixing the charger cable to the Wing.  
# There were no LOC, just normal flight to Bristol and return, with no lift.
# a  6 channel SPG IFI using  t, Ax, Ay, beta, alpha, vrel, P
# Run SPG IFI using  file data, pre assigned datazero
# model 
# test tensorflow import
#import tensorflow as tf
#from tensorflow import keras
#from sklearn.model_selection import train_test_split #for training only
import numpy as np
import time
import math
import matplotlib.pyplot as plt #slow load
import os

__author__ = "Colin Michael Foale/FAERO derived from Jonathan Macoskey"
__copyright__ = "Robert Bosch LLC Research and Technology Center North America"
__version__ = "1.0"
__maintainer__ = "Colin Michael Foale"
__email__ = "cmfoale@outlook"

global datazero, losses, npoints, model, datafilepath, bestmodelfilepath
global modelfilepath,oofmaximumsfilepath
#os.chdir('/home/cmf/ml/tf/2-11-2020/wing') #BE SURE THIS IS THE CORRECT PATH
start = 0 
finish = 0 #set to 0 to use all the data
moving_average = 4 #Average current point with 3 previous measurements - this effects import_data
datafilepath = './2020_03_24_140.dat'
bestmodelfilepath = './2020_03_24_140_air_bestmodelv6.h5'
modelfilepath = './2020_03_24_140_air_modelv6.h5'
oofmaximumsfilepath = './2020_03_24_140_air_oof_max.npy'

datazero = [519.1479591836735,
 397.71938775510205,
 833.4183673469388,
 795.984693877551,
 827.4438775510204,
 730.5714285714286]

params = {
        'hfactor': 1,
        'num_channels': 6,
        'period': 45,
        'num_hidden_layers': 3,
        }

def get_model(params, path):
    '''Makes TF IFI Model'''
    elems = [params['hfactor'] * params['num_channels'] * params['period']] * params['num_hidden_layers']
    print("num channels: ", params['num_channels'])
    print("period: ", params['period'])
# Load model 
    model = keras.models.load_model(path)
    #optimizer = tf.keras.optimizers.RMSprop(0.001)
    #model.compile(loss='mse', optimizer=optimizer, metrics=['mae', 'mse'], run_eagerly=True) # this causes failure by input dimensions
    # model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'], run_eagerly=True)
    model.summary()
    return model

def import_data(path):
    '''imports data as np.array'''
    data = np.loadtxt(path)  # all 6 channel required
    if finish == 0:
        td = np.transpose(data)
    else:
        td = np.transpose(data[start:finish]) #take off to landing 14500
    selected = [td[0],td[1],td[2],td[4],td[5],td[6],td[7]] # t, Ax, Ay,dpz, dpy, dpx, P
    #selected = data.tolist() # can choose a range here  e.g. [2000:]
    #apply moving average
    if moving_average > 1:
        selected = mav(selected, moving_average)
    return np.transpose(selected)  #must return an np array

def mav(data_by_row,N):  #moving average of N points in the past (mode ='same' )
    x = data_by_row[0] #time is first row, which should not be averaged
    rmlength = len(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):]) # mav is done to get length only
    rm = []
    rm.append(np.array(data_by_row[0][0:rmlength]))
    for j in range(1,np.shape(data_by_row)[0]):
        x = data_by_row[j]
        rm.append(np.convolve(x, np.ones((N,))/N, mode='same')[(N-1):])
    return rm

def GetDataZero(data,number_of_takes=25): #cmf - we should only do this once, if we are running an online prediction
    # Get mean of first 25 samples and store value 
    dz = []
    for idx in range(1, np.shape(data)[1]):
        dz.append(np.mean(data[0:number_of_takes, idx]))
    return dz

# make a function to normalize a single line from the import
# requires global datazero to have been calculatated
def normalize(channels):
    channel_range = 1024 # a characteristice range of data values, min to max
    rv = []
    for idx in range(0,len(channels)):
        if idx == 1: #Ay
            rv.append((channels[idx] - datazero[idx]) / (2*channel_range))
        else :
            rv.append((channels[idx] - datazero[idx]) / channel_range)
    return rv

def normalize_data(raw_data): # cmf note data is passed by reference!
    # Normalize all the data rows np.shape(data)[1]
    global noddata
    noddata = []
    for idx in range(0, np.shape(raw_data)[0]): # all the rows of data
        tmp = normalize(raw_data[idx,1:]) #skip the first column with time/index
        noddata.append(tmp)
    return noddata

def onepair(nd): # nd is noddata from the preceding 'period' rows, with the 'period+1'th
    #expecting period + 1 rows
    td = np.array(nd).copy() # so we do not pollute nd refference
    td = np.transpose(td).tolist() #now period + 1 columns
    instances = []
    labels = []
    period = params['period']
    inst = []
    labl = []
    for ch in range(0,params['num_channels']):
        inst.append(td[ch][:period])         
        labl.append(td[ch][period])

    instances.append( [item for sublist in inst for item in sublist]) # flatten the list
    labels.append(labl)
    return instances, labels

def plot_raw_data(start_idx=0,finish_idx=0, plot_raw=True,plot_normalized=False, plot_intervals=True):
    #import matplotlib.pyplot as plt #slow load
    global filepath, datazero
    data = np.loadtxt(datafilepath)
    if finish_idx == 0:
        finish_idx = len(data)
    rawchannels = np.shape(data)[1]
    data = np.transpose(data[start_idx:finish_idx])
    times = data[0] # save for separate plot
    data = np.transpose(data[1:rawchannels]) #drop the time values in first row
    fig0,ax = plt.subplots(nrows=3,ncols=1,figsize=(12,6))
    fig0.suptitle(datafilepath)
    if plot_raw:
        ax[0].set_title('data beginning at ' + str(start_idx))
        ax[0].set_ylabel('Raw')
        ax[0].plot(data,label=['Ax', 'Ay', 'Az','dPz', 'dPy', 'dPx','P','Vbat'])
        handles, labels = ax[0].get_legend_handles_labels()
        ax[0].legend(handles, ['Ax', 'Ay', 'Az','dPz', 'dPy', 'dPx','P','Vbat'])
        ax[0].grid(True)
    
    #plot normalized selected data
    if plot_normalized:
        datazero = GetDataZero(import_data(datafilepath)) # assumes nominal non-dynamic data at the beginning
        noddata = normalize_data(import_data(datafilepath)[start_idx:finish_idx])
        ax[1].set_ylabel('Normalized')
        ax[1].plot(noddata,label=['Ax', 'Ay','dPz', 'dPy', 'dPx','P'])
        handles, labels = ax[1].get_legend_handles_labels()
        ax[1].legend(handles, ['Ax', 'Ay', 'Az', 'dPy', 'dPx','P'])
        ax[1].grid(True)
    
    # plot times and intervals
    if plot_intervals:
        intervals = [0]
        for i in range(1,len(times)):
            intervals.append((times[i] - times[i-1])*1000)
        #ax[2].set_ylim(0,1)  #use if we have a short data take
        ax[2].plot(list(range(start_idx,finish_idx)),times,list(range(start_idx,finish_idx)),intervals,label=['time','intervals'])
        ax[2].legend(handles, ['time (s)','intervals (ms)'])
        ax[2].grid(True)
    
    #plt.gca().set_ylim(0,1)
    #plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False) #needed for IDE
    return

# return long arrays of actual and predicted values for plotting or differencing
#assumes preprocess_data has already been run, to create global noddata
def actual_to_predicted(start_idx,finish_idx):
# create prediction by running over noddata and feeding it to evaluate
    period = params['period']
    if len(noddata)-period-1 < finish_idx:
        finish_idx = len(noddata)-period-1 # we only have this many points to compare
    predictions = []
    targets = []
    for idx in range(start_idx,finish_idx):
        inst, t = onepair(noddata[idx:idx+period+1])
        p = model.predict_on_batch((inst,t)).numpy().tolist()[0]
        #p = model.predict(inst).tolist()[0] # element list of list
        predictions.append(p)
        targets.append(t[0]) # element list of list
    return targets, predictions


# return long arrays of actual and predicted values for plotting or differencing
#assumes preprocess_data has already been run, to create global noddata
def plot_actual_to_predicted(start_idx,finish_idx):
    import matplotlib.pyplot as plt #slow load
    t, p = actual_to_predicted(start_idx, finish_idx)
    plt .plot(t)
    plt.plot(p)
    plt.grid(True)
    #plt.gca().set_ylim(0,1)
    #plt.ion()
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False)
    return

def out_of_family(t, p):
    nchannels = params['num_channels']
    oof = np.empty((0,nchannels), float)
    for idx in range(0,np.shape(t)[0]): # the length of the data
        channels = np.empty([1,nchannels], float)
        for ch in range(0,nchannels): # the channels
            val = math.sqrt((t[idx][ch] - p[idx][ch])*(t[idx][ch] - p[idx][ch]))
            channels[0,ch]=val
        oof = np.append(oof,channels,axis=0)
    return oof

def plot_oof_over_maximum(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(noddata)-params['period']
    t, p = actual_to_predicted(start_idx, finish_idx)
    oofmax = np.load(oofmaximumsfilepath)
    oof = out_of_family(t,p)
    on=[]
    for i in range(0,len(oofmax)):
        on.append(oof[:,i]/oofmax[i])
    on = np.transpose(on)
    fig0,ax1 = plt.subplots(nrows=1,ncols=1,figsize=(12,6))
    fig0.suptitle(datafilepath)
    ax1.set_title('Out of Family over Maximum, beginning at ' + str(start_idx))
    ax1.plot(on,label=['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    handles, labels = ax1.get_legend_handles_labels()
    ax1.legend(handles, ['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    ax1.grid(True)
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False)
    return

def plot_actual_to_oof(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(noddata)-params['period']
    t, p = actual_to_predicted(start_idx, finish_idx)
    oof = out_of_family(t,p)
    fig3,ax = plt.subplots(nrows=2,ncols=1,figsize=(12,6))
    fig3.suptitle( modelfilepath )

    ax[0].set_title('Actual c.f. Out of Family, beginning at ' + str(start_idx))
    ax[0].plot(t,label=['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    handles, labels = ax[0].get_legend_handles_labels()
    ax[0].legend(handles, ['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    ax[0].grid(True)

    ax[1].plot(oof,label=['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].legend(handles, ['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].grid(True)
    #plt.gca().set_ylim(0,1)
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False)
    return

def inference():
    tstart = time.clock_gettime(0)
    npoints = 1
    for n in range(0,npoints): #len(noddata)-params['period']
        for i in range(0,len(noddata)-params['period']):
            t, p = actual_to_predicted(i, i+1)
            oof = out_of_family(t,p)
    # print("oof "+str(oof))
    tend = time.clock_gettime(0)
    interval = (tend - tstart)/(npoints*(len(noddata)-params['period']))
    print("Inference time (6) " + str(interval/1))
    return

def plot_predicted_to_oof(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(noddata)-params['period']
    t, p = actual_to_predicted(start_idx, finish_idx)
    oof = out_of_family(t,p)
    fig4,ax = plt.subplots(nrows=2,ncols=1,figsize=(12,6))
    fig4.suptitle(datafilepath + str(' + ') + modelfilepath )

    ax[0].set_title('Predicted c.f. Out of Family, beginning at ' + str(start_idx))
    ax[0].plot(p,label=['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    handles, labels = ax[0].get_legend_handles_labels()
    ax[0].legend(handles, ['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    ax[0].grid(True)

    ax[1].plot(oof,label=['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].legend(handles, ['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].grid(True)
    #plt.gca().set_ylim(0,1)
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False)


def plot_predicted_to_oof_over_maximum(start_idx=0,finish_idx=0):
    import matplotlib.pyplot as plt #slow load
    if finish_idx == 0:
        finish_idx = len(noddata)-params['period']
    t, p = actual_to_predicted(start_idx, finish_idx)
    oof = out_of_family(t,p)
    fig4,ax = plt.subplots(nrows=2,ncols=1,figsize=(12,6))
    #fig4=plt.figure(4)
    fig4.suptitle(datafilepath + str(' + ') + modelfilepath )

    ax[0].set_title('Predicted c.f. Out of Family over Maximums, beginning at ' + str(start_idx))
    ax[0].plot(p,label=['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    handles, labels = ax[0].get_legend_handles_labels()
    ax[0].legend(handles, ['Ax', 'Ay', 'dPz', 'dPy', 'dPx','P'])
    ax[0].grid(True)
    #calculate the ration of oof to the maximums seen in training
    oofmax = np.load(oofmaximumsfilepath)
    on=[]
    for i in range(0,len(oofmax)):
        on.append(oof[:,i]/oofmax[i])
    on = np.transpose(on)
    
    ax[1].plot(on,label=['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].legend(handles, ['oof Ax', 'oof Ay', 'oof dPz', 'oof dPy', 'oof dPx','oof P'])
    ax[1].grid(True)
    #plt.gca().set_ylim(0,1)
    plt.pause(1) # allows the plot to be drawn.  enter plt.show(block=True) to close it
    plt.show(block=False)
    return

def plots():   
    plot_actual_to_oof()
    return

def ask_for_data_filename_dialog():
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    filename = filedialog.askopenfilename()
    return filename

def main():
    global model, noddata, datafilepath, params,datazero
    #datazero = GetDataZero(import_data(datafilepath))  #not required if specified above
    print('datazero is ..')
    print(datazero) # assigned at the top of this file
    noddata = normalize_data(import_data(datafilepath))
    model = get_model(params, modelfilepath)
    print("noddata length is %d" % len(noddata))
    print("predicted data length is " + str(len(noddata)-params['period']))
    #values, labels = preprocess_data(import_data(filepath)) # creates noddata
    #plots()
    return

datafilepath = ask_for_data_filename_dialog() 
#plot_raw_data(finish_idx=0)
#main()
#plot_oof_over_maximum()
plot_raw_data(plot_raw=True,plot_normalized=True, plot_intervals=True)
#plot_predicted_to_oof_over_maximum()
plt.show() #seems to let the created plots be painted
#plot_actual_to_oof()



