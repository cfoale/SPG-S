#!/bin/bash
echo 'run_cockpit.sh'
#echo 'turn off bluetooth 20'
#sudo rfkill block bluetooth
#echo 'sleep 20 secs'
#sleep 20
#echo 'turn on bluetooth'
#sudo rfkill unblock bluetooth
cd /home/pi/ml
sudo iwconfig wlan0 txpower 16
echo 'wlan0 tx set to 16'
sudo uhubctl -l 1-1.1 -p 2 -a 0
echo 'secondary USB port 2 turned off'
sudo uhubctl -l 1-1.1 -p 3 -a 0
echo 'secondary USB port 3 turned off'
sudo /usr/bin/tvservice -o
echo 'HDMI turned off'
echo 'run_cockpit started RunCockpitv0.51.py'
/usr/bin/python3 /home/pi/ml/RunCockpitv0.51.py
 



