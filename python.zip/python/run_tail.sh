#!/bin/bash
echo 'run_tail.sh'
cd /home/pi/ml
sudo iwconfig wlan0 txpower 32
echo 'wlan0 tx set to 1'
#sudo uhubctl -l 1-1.1 -p 2 -a 0
#echo 'secondary USB port 2 turned off'
#sudo uhubctl -l 1-1.1 -p 3 -a 0
#echo 'secondary USB port 3 turned off'
sudo /usr/bin/tvservice -o
echo 'HDMI turned off'
echo 'run_tail.sh started RunTailv0.1.py'
sudo /usr/bin/python3 /home/pi/ml/RunTailv0.2.py

 



