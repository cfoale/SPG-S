#!/bin/bash
echo 'run_wing.sh'
cd /home/pi/ml
sudo iwconfig wlan0 txpower 32
echo  'wlan0 tx set to 32'
sudo /usr/bin/tvservice -o
echo 'HDMI turned off'
echo 'run_wing.sh started Runwingv0.51.py'
sudo /usr/bin/python3 RunWingv0.51.py


